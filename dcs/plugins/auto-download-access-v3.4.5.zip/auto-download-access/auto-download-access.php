<?php
/**
 * Plugin Name:       Dostęp do zdjęć
 * Plugin URI:        https://twoja-strona.pl/
 * Description:       Zarządzaj dostępem do pobierania zdjęć dla klientów po zakupie w WooCommerce.
 * Version:           3.4.5
 * Author:            Łukasz Margol
 * Author URI:        https://twoja-strona.pl/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       auto-download-access
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Auto_Download_Access {

    private $option_name = 'ada_settings';
    private $standalone_token_option_name = 'ada_standalone_refresh_token';
    private $file_status_cache = [];

    public function __construct() {
        add_action( 'plugins_loaded', [ $this, 'load_textdomain' ] );
        add_action( 'admin_menu', [ $this, 'add_admin_menu_pages' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'admin_init', [ $this, 'handle_google_oauth_callback' ] );
        add_action( 'admin_init', [ $this, 'handle_form_actions' ] );
        add_action( 'admin_init', [ $this, 'handle_reset_action' ] );
        add_action( 'admin_init', [ $this, 'handle_clear_cache_action' ] );
        add_action( 'admin_notices', [ $this, 'show_admin_notices' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
        add_action( 'wp_ajax_ada_save_manual_link', [ $this, 'ajax_save_manual_link' ] );
        add_action( 'wp_ajax_ada_disconnect_manual_link', [ $this, 'ajax_disconnect_manual_link' ] );

        // MODYFIKACJA 3.4.3 - WooCommerce My Account endpoint dla klientów
        add_action( 'init', [ $this, 'add_my_account_endpoint' ] );
        add_filter( 'woocommerce_account_menu_items', [ $this, 'add_my_account_menu_item' ] );
        add_action( 'woocommerce_account_photo-downloads_endpoint', [ $this, 'render_my_account_photo_downloads' ] );
    }

    public function load_textdomain() {
        load_plugin_textdomain('auto-download-access', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }

    // MODYFIKACJA 3.4.3 - WooCommerce My Account endpoint
    public function add_my_account_endpoint() {
        add_rewrite_endpoint( 'photo-downloads', EP_ROOT | EP_PAGES );
    }

    public function add_my_account_menu_item( $items ) {
        // Usuń domyślną zakładkę WooCommerce "Downloads" (duplikat)
        if ( isset( $items['downloads'] ) ) {
            unset( $items['downloads'] );
        }

        // Dodaj "Pobierz zdjęcia" przed "Wyloguj"
        $logout = $items['customer-logout'];
        unset( $items['customer-logout'] );
        $items['photo-downloads'] = __( 'Pobierz zdjęcia', 'auto-download-access' );
        $items['customer-logout'] = $logout;
        return $items;
    }

    public function render_my_account_photo_downloads() {
        $customer_id = get_current_user_id();
        if ( ! $customer_id ) return;

        $customer_orders = wc_get_orders( [
            'customer' => $customer_id,
            'status' => [ 'completed', 'processing' ],
            'limit' => -1,
            'orderby' => 'date',
            'order' => 'DESC'
        ] );

        ?>
        <h2><?php _e( 'Twoje zdjęcia', 'auto-download-access' ); ?></h2>
        <p><?php _e( 'Poniżej znajdziesz wszystkie zdjęcia z Twoich zamówień gotowe do pobrania.', 'auto-download-access' ); ?></p>

        <?php if ( empty( $customer_orders ) ): ?>
            <p><?php _e( 'Nie znaleziono zamówień ze zdjęciami cyfrowymi.', 'auto-download-access' ); ?></p>
        <?php else: ?>
            <?php foreach ( $customer_orders as $order ): ?>
                <?php
                $digital_items = [];
                foreach ( $order->get_items() as $item_id => $item ) {
                    foreach ( $item->get_formatted_meta_data( '_', true ) as $meta ) {
                        if ( strtolower($meta->key) === 'wersja elektroniczna' ) {
                            $product = $item->get_product();
                            $sku = $product ? $product->get_sku() : '';
                            $product_name = $item->get_name();

                            // Sprawdź czy jest manual link
                            $download_link = wc_get_order_item_meta( $item_id, '_ada_manual_file_link', true );

                            // Jeśli nie ma manual link, szukaj w Google Drive (używając cache)
                            if ( empty( $download_link ) && ( $sku || $product_name ) ) {
                                $download_link = $this->get_download_link_for_product( $product_name, $sku );
                            }

                            if ( ! empty( $download_link ) ) {
                                $digital_items[] = [
                                    'name' => $product_name,
                                    'link' => $download_link,
                                    'thumbnail' => $product ? $product->get_image( 'thumbnail' ) : ''
                                ];
                            }
                        }
                    }
                }

                if ( ! empty( $digital_items ) ):
                ?>
                    <div style="margin-bottom: 30px; padding: 20px; border: 1px solid #ddd; border-radius: 4px; background: #f9f9f9;">
                        <h3 style="margin-top: 0;">
                            <?php printf( __( 'Zamówienie #%s', 'auto-download-access' ), $order->get_order_number() ); ?>
                            <span style="color: #777; font-size: 0.9em; font-weight: normal;">
                                (<?php echo wc_format_datetime( $order->get_date_created() ); ?>)
                            </span>
                        </h3>

                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px;">
                            <?php foreach ( $digital_items as $item ): ?>
                                <div style="border: 1px solid #e0e0e0; padding: 15px; background: white; border-radius: 4px; text-align: center;">
                                    <?php if ( ! empty( $item['thumbnail'] ) ): ?>
                                        <div style="margin-bottom: 10px;">
                                            <?php echo $item['thumbnail']; ?>
                                        </div>
                                    <?php endif; ?>
                                    <div style="margin-bottom: 10px; font-weight: bold;">
                                        <?php echo esc_html( $item['name'] ); ?>
                                    </div>
                                    <a href="<?php echo esc_url( $item['link'] ); ?>"
                                       class="button"
                                       target="_blank"
                                       style="background: #0073aa; color: white; text-decoration: none; padding: 8px 15px; border-radius: 3px; display: inline-block;">
                                        <?php _e( 'Pobierz', 'auto-download-access' ); ?>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php
                endif;
            endforeach;
            ?>
        <?php endif; ?>
        <?php
    }

    // MODYFIKACJA 3.1.1 - Dodanie brakującego stringu 'disconnect'
    public function enqueue_admin_scripts($hook) {
        $parent_slug = 'ada-assign-access';
        $pages = [
            'toplevel_page_' . $parent_slug,
            $parent_slug . '_page_ada-assign-access',
            $parent_slug . '_page_ada-history',
            $parent_slug . '_page_ada-settings',
            $parent_slug . '_page_ada-email-template',
        ];

        if (!in_array($hook, $pages)) {
            return;
        }

        wp_enqueue_script(
            'ada-admin-script',
            plugin_dir_url(__FILE__) . 'assets/js/admin.js',
            ['jquery'],
            '3.4.5', // MODYFIKACJA 3.4.5 - Polskie tłumaczenia + fix statusu
            true
        );
        wp_enqueue_script(
            'google-picker',
            'https://apis.google.com/js/api.js?onload=adaOnGoogleApiLoad',
            ['ada-admin-script'], 
            null,
            true
        );

        $options = get_option($this->option_name);
        $access_token = $this->get_google_api_access_token();
        wp_localize_script('ada-admin-script', 'ada_picker_vars', [
            'clientId'    => $options['google_client_id'] ?? '',
            'accessToken' => $access_token,
            'folderId'    => $options['google_folder_id'] ?? '',
            'ajax_url'    => admin_url('admin-ajax.php'),
            'nonce'       => wp_create_nonce('ada-manual-link-nonce'),
            'linkSaved'   => __('Powiązano ręcznie', 'auto-download-access'),
            'pasteUrlPrompt' => __('Wklej pełny adres URL do pliku:', 'auto-download-access'),
            'invalidUrl'  => __('Nieprawidłowy URL. Upewnij się że zaczyna się od http:// lub https://', 'auto-download-access'),
            'notFound'        => __('Nie znaleziono', 'auto-download-access'),
            'searchedFor'     => __('(SKU: %s) Szukano: %s', 'auto-download-access'),
            'chooseFromDrive' => __('Wybierz z dysku Google', 'auto-download-access'),
            'pasteManually'   => __('Wklej link ręcznie', 'auto-download-access'),
            'disconnect'      => __('Odłącz', 'auto-download-access'),
            'change'          => __('Zmień', 'auto-download-access'),
            'cancel'          => __('Anuluj', 'auto-download-access'),
        ]);
    }

    // MODYFIKACJA 3.4.1 - Czyści cache dla produktu
    private function clear_product_cache($item_id) {
        $item = new WC_Order_Item_Product($item_id);
        $product = $item->get_product();
        $sku = $product ? $product->get_sku() : '';
        $product_name = $item->get_name();

        $cache_key = 'ada_file_' . md5($product_name . '|' . $sku);
        delete_transient($cache_key);
    }

    public function ajax_save_manual_link() {
        check_ajax_referer('ada-manual-link-nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }
        $item_id = isset($_POST['item_id']) ? absint($_POST['item_id']) : 0;
        $file_url = isset($_POST['file_url']) ? esc_url_raw(trim($_POST['file_url'])) : '';

        if ($item_id && !empty($file_url) && filter_var($file_url, FILTER_VALIDATE_URL)) {
            wc_update_order_item_meta($item_id, '_ada_manual_file_link', $file_url);
            // Wyczyść cache aby odświeżyć status
            $this->clear_product_cache($item_id);
            wp_send_json_success();
        }
        wp_send_json_error(['message' => __('Invalid data.', 'auto-download-access')]);
    }

    public function ajax_disconnect_manual_link() {
        check_ajax_referer('ada-manual-link-nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }
        $item_id = isset($_POST['item_id']) ? absint($_POST['item_id']) : 0;
        if ($item_id) {
            wc_delete_order_item_meta($item_id, '_ada_manual_file_link');
            // Wyczyść cache aby odświeżyć status
            $this->clear_product_cache($item_id);
            wp_send_json_success();
        }
        wp_send_json_error(['message' => __('Invalid data.', 'auto-download-access')]);
    }

    public function add_admin_menu_pages() {
        add_menu_page(__( 'Photo Access', 'auto-download-access' ), __( 'Photo Access', 'auto-download-access' ), 'manage_options', 'ada-assign-access', [ $this, 'render_admin_page' ], 'dashicons-download', 25);
        add_submenu_page('ada-assign-access', __( 'Assign Access', 'auto-download-access' ), __( 'Assign Access', 'auto-download-access' ), 'manage_options', 'ada-assign-access', [ $this, 'render_admin_page' ]);
        add_submenu_page('ada-assign-access', __( 'Access History', 'auto-download-access' ), __( 'History', 'auto-download-access' ), 'manage_options', 'ada-history', [ $this, 'render_history_page' ]);
        add_submenu_page('ada-assign-access', __( 'Settings', 'auto-download-access' ), __( 'Settings', 'auto-download-access' ), 'manage_options', 'ada-settings', [ $this, 'render_settings_page' ]);
        add_submenu_page('ada-assign-access', __( 'Email Templates', 'auto-download-access' ), __( 'Email Templates', 'auto-download-access' ), 'manage_options', 'ada-email-template', [ $this, 'render_email_template_page' ]);
    }

    public function register_settings() {
        register_setting( $this->option_name, $this->option_name, [ $this, 'sanitize_settings' ] );
    }

    public function handle_reset_action() {
        if ( isset( $_POST['ada_reset_settings'] ) && check_admin_referer( 'ada_reset_nonce_action', 'ada_reset_nonce' ) ) {
            if ( ! current_user_can( 'manage_options' ) ) return;
            delete_option( $this->option_name );
            delete_option( $this->standalone_token_option_name );
            set_transient( 'ada_admin_notice', [ 'message' => __( 'Settings have been successfully reset.', 'auto-download-access' ), 'type' => 'success' ], 5 );
            wp_safe_redirect( admin_url( 'admin.php?page=ada-assign-access' ) );
            exit;
        }
    }

    // MODYFIKACJA 3.4.1 - Handler do czyszczenia cache
    public function handle_clear_cache_action() {
        if ( isset( $_POST['ada_clear_cache'] ) && check_admin_referer( 'ada_clear_cache_nonce_action', 'ada_clear_cache_nonce' ) ) {
            if ( ! current_user_can( 'manage_options' ) ) return;

            global $wpdb;
            // Usuń wszystkie transients zaczynające się od 'ada_file_'
            $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ada_file_%' OR option_name LIKE '_transient_timeout_ada_file_%'" );

            set_transient( 'ada_admin_notice', [ 'message' => __( 'File cache has been cleared successfully. The page will reload to show fresh data from Google Drive.', 'auto-download-access' ), 'type' => 'success' ], 5 );
            wp_safe_redirect( admin_url( 'admin.php?page=ada-settings' ) );
            exit;
        }
    }

    public function sanitize_settings( $input ) {
        $current_options = get_option($this->option_name, []);
        $new_input = $current_options;
        if (isset($input['google_client_id'])) $new_input['google_client_id'] = sanitize_text_field( trim($input['google_client_id']) );
        if (isset($input['google_client_secret'])) $new_input['google_client_secret'] = sanitize_text_field( trim($input['google_client_secret']) );
        if (isset($input['google_folder_id'])) $new_input['google_folder_id'] = sanitize_text_field( trim($input['google_folder_id']) );
        if (isset($input['email_subject'])) $new_input['email_subject'] = sanitize_text_field( $input['email_subject'] );
        if (isset($input['email_body'])) $new_input['email_body'] = wp_kses_post( $input['email_body'] );
        return $new_input;
    }

    public function handle_google_oauth_callback() {
        if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'ada-settings' || ! isset( $_GET['code'] ) ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;

        $options = get_option( $this->option_name );
        $client_id = $options['google_client_id'] ?? '';
        $client_secret = $options['google_client_secret'] ?? '';
        $redirect_uri = admin_url( 'admin.php?page=ada-settings' );

        $response = wp_remote_post( 'https://oauth2.googleapis.com/token', [
            'body' => [
                'code' => sanitize_text_field( $_GET['code'] ), 'client_id' => $client_id, 'client_secret' => $client_secret,
                'redirect_uri' => $redirect_uri, 'grant_type' => 'authorization_code',
            ],
        ]);
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            $error_message = __( 'Failed to get refresh token from Google.', 'auto-download-access' );
            if (isset($body['error_description'])) $error_message .= ' ' . __('Details:', 'auto-download-access') . ' ' . $body['error_description'];
            elseif (is_wp_error($response)) $error_message .= ' ' . __('Details:', 'auto-download-access') . ' ' . $response->get_error_message();
            set_transient( 'ada_admin_notice', [ 'message' => $error_message, 'type' => 'error' ], 15 );
        } elseif ( isset( $body['refresh_token'] ) ) {
            update_option( $this->standalone_token_option_name, $body['refresh_token'] );
            set_transient( 'ada_admin_notice', [ 'message' => __( 'Application is authorized.', 'auto-download-access' ), 'type' => 'success' ], 5 );
        } else {
            set_transient( 'ada_admin_notice', [ 'message' => __( 'Authorization successful, but Google did not return a refresh token. Please try resetting settings.', 'auto-download-access' ), 'type' => 'warning' ], 5 );
        }
        wp_safe_redirect( add_query_arg( 'ada_cache_bust', wp_create_nonce('ada-bust'), $redirect_uri ) );
        exit;
    }

    private function get_google_api_access_token() {
        $refresh_token = get_option( $this->standalone_token_option_name );
        if ( empty( $refresh_token ) ) return null;
        $access_token = get_transient( 'ada_google_access_token' );
        if ($access_token) return $access_token;
        $options = get_option( $this->option_name );
        $response = wp_remote_post( 'https://oauth2.googleapis.com/token', [
            'body' => [
                'client_id' => $options['google_client_id'], 'client_secret' => $options['google_client_secret'],
                'refresh_token' => $refresh_token, 'grant_type' => 'refresh_token',
            ],
        ]);
        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) return null;
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( isset( $body['access_token'] ) ) {
            set_transient( 'ada_google_access_token', $body['access_token'], $body['expires_in'] - 60 );
            return $body['access_token'];
        }
        return null;
    }

    // MODYFIKACJA 3.3.0 - Funkcja pomocnicza do normalizacji (usuwanie polskich znaków)
    private function normalize_string($str) {
        $base_str = preg_replace('/-\d+$/', '', $str);
        if (function_exists('transliterator_transliterate')) {
            $transliterator = Transliterator::createFromRules(':: Any-Latin; :: Latin-ASCII; :: NFD; :: [:Nonspacing Mark:] Remove; :: NFC;', Transliterator::FORWARD);
            $normalized_str = $transliterator->transliterate($base_str);
        } else {
            $char_map = [
                'ą' => 'a', 'ć' => 'c', 'ę' => 'e', 'ł' => 'l', 'ń' => 'n',
                'ó' => 'o', 'ś' => 's', 'ź' => 'z', 'ż' => 'z',
                'Ą' => 'A', 'Ć' => 'C', 'Ę' => 'E', 'Ł' => 'L', 'Ń' => 'N',
                'Ó' => 'O', 'Ś' => 'S', 'Ź' => 'Z', 'Ż' => 'Z',
            ];
            $normalized_str = strtr($base_str, $char_map);
        }
        return $normalized_str;
    }

    // MODYFIKACJA 3.3.0 - Generuje warianty nazwy pliku do wyszukiwania
    // Priorytet: 1) Nazwa produktu, 2) SKU, 3) Znormalizowane wersje
    private function get_filename_variations($product_name, $sku) {
        $variations = [];

        // Usuwamy -liczba z końca nazwy produktu (np. "-1")
        $base_product_name = preg_replace('/-\d+$/', '', $product_name);
        $base_sku = preg_replace('/-\d+$/', '', $sku);

        // 1. Priorytet: Nazwa produktu (z polskimi znakami)
        if (!empty($base_product_name)) {
            $variations[] = $base_product_name;
        }

        // 2. Priorytet: SKU (może zawierać podkreślenia zamiast polskich znaków)
        if (!empty($base_sku) && $base_sku !== $base_product_name) {
            $variations[] = $base_sku;
        }

        // 3. Priorytet: Znormalizowana nazwa produktu (fallback)
        if (!empty($base_product_name)) {
            $normalized_name = $this->normalize_string($base_product_name);
            if (!in_array($normalized_name, $variations)) {
                $variations[] = $normalized_name;
            }
        }

        // 4. Priorytet: Znormalizowany SKU (fallback)
        if (!empty($base_sku)) {
            $normalized_sku = $this->normalize_string($base_sku);
            if (!in_array($normalized_sku, $variations)) {
                $variations[] = $normalized_sku;
            }
        }

        return $variations;
    }

    // MODYFIKACJA 3.3.8 - Funkcja do escapowania dla Google Drive API query
    private function escape_drive_query_value($value) {
        // Google Drive API wymaga escapowania \ i '
        $value = str_replace('\\', '\\\\', $value);
        $value = str_replace("'", "\\'", $value);
        return $value;
    }

    // MODYFIKACJA 3.4.1 - Wielostrategiowe wyszukiwanie ZOPTYMALIZOWANE (mniej prób)
    private function search_google_drive_file_multiple($filename_variations, $debug = false) {
        $access_token = $this->get_google_api_access_token();
        if ( ! $access_token ) return null;
        $options = get_option($this->option_name);
        $folder_id = $options['google_folder_id'] ?? '';

        $debug_info = [];

        // STRATEGIA 1: Exact match (case-sensitive) dla WSZYSTKICH wariantów
        foreach ($filename_variations as $filename) {
            $result = $this->try_drive_search($access_token, $filename, $folder_id, 'exact', $debug_info);
            if ($result) return $result;
        }

        // STRATEGIA 2: Case variations TYLKO dla pierwszego wariantu (product_name)
        // To oszczędza mnóstwo API calls!
        if (!empty($filename_variations[0])) {
            $primary_filename = $filename_variations[0];

            // Próbujemy Title Case (każde słowo z dużej litery)
            $title_case = mb_convert_case($primary_filename, MB_CASE_TITLE, 'UTF-8');
            if ($title_case !== $primary_filename) {
                $result = $this->try_drive_search($access_token, $title_case, $folder_id, 'title-case', $debug_info);
                if ($result) return $result;
            }

            // Próbujemy lowercase
            $lowercase = mb_strtolower($primary_filename, 'UTF-8');
            if ($lowercase !== $primary_filename) {
                $result = $this->try_drive_search($access_token, $lowercase, $folder_id, 'lowercase', $debug_info);
                if ($result) return $result;
            }

            // Próbujemy UPPERCASE
            $uppercase = mb_strtoupper($primary_filename, 'UTF-8');
            if ($uppercase !== $primary_filename) {
                $result = $this->try_drive_search($access_token, $uppercase, $folder_id, 'uppercase', $debug_info);
                if ($result) return $result;
            }

            // STRATEGIA 3: fullText contains TYLKO dla pierwszego wariantu
            $result = $this->try_drive_search($access_token, $primary_filename, $folder_id, 'contains', $debug_info);
            if ($result) return $result;

            // STRATEGIA 4: Rekursywne wyszukiwanie TYLKO dla pierwszego wariantu
            if ($folder_id) {
                $result = $this->try_drive_search($access_token, $primary_filename, '', 'recursive', $debug_info);
                if ($result) return $result;
            }
        }

        if ($debug) {
            return ['files' => [], 'debug_info' => $debug_info];
        }
        return null;
    }

    // MODYFIKACJA 3.4.0 - Pomocnicza funkcja do pojedynczej próby wyszukiwania
    private function try_drive_search($access_token, $filename, $folder_id, $strategy, &$debug_info) {
        $escaped_filename = $this->escape_drive_query_value($filename);

        // Budujemy query w zależności od strategii
        if ($strategy === 'contains') {
            // fullText contains jest case-insensitive
            $query = "fullText contains '" . $escaped_filename . "' and trashed=false and mimeType contains 'image/'";
        } else {
            // exact, title-case, lowercase, uppercase, recursive używają name=
            $query = "name='" . $escaped_filename . ".jpg' and trashed=false";
        }

        // Dodajemy ograniczenie folderu (jeśli nie jest to strategia recursive)
        if ($folder_id && $strategy !== 'recursive') {
            $escaped_folder = $this->escape_drive_query_value($folder_id);
            $query .= " and '" . $escaped_folder . "' in parents";
        }

        $search_url = 'https://www.googleapis.com/drive/v3/files?' . http_build_query(['q' => $query, 'fields' => 'files(id, name, webViewLink, parents)', 'corpora' => 'user']);
        $response = wp_remote_get( $search_url, ['headers' => [ 'Authorization' => 'Bearer ' . $access_token ]]);

        $debug_entry = [
            'searched' => $filename . '.jpg',
            'query' => $query,
            'strategy' => $strategy,
            'response_code' => is_wp_error($response) ? 'error' : wp_remote_retrieve_response_code($response),
            'found' => false
        ];

        if ( !is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
            $data = json_decode( wp_remote_retrieve_body( $response ), true );
            if ( !empty( $data['files'] ) ) {
                // Dla contains strategy, filtrujemy wyniki aby znaleźć dokładne dopasowanie
                $matched_file = null;
                foreach ($data['files'] as $file) {
                    $file_basename = pathinfo($file['name'], PATHINFO_FILENAME);
                    // Case-insensitive porównanie
                    if (mb_strtolower($file_basename, 'UTF-8') === mb_strtolower($filename, 'UTF-8')) {
                        $matched_file = $file;
                        break;
                    }
                }

                if ($matched_file) {
                    $debug_entry['found'] = true;
                    $debug_entry['found_file'] = $matched_file['name'];
                    $debug_info[] = $debug_entry;

                    return [
                        'files' => [$matched_file],
                        'matched_filename' => $filename,
                        'debug_info' => $debug_info
                    ];
                }
            }
        }

        $debug_info[] = $debug_entry;
        return null;
    }

    // MODYFIKACJA 3.4.3 - Ulepszone cache z diagnostyką i fallback
    private function get_cached_drive_file($product_name, $sku, $debug = false) {
        $cache_key = 'ada_file_' . md5($product_name . '|' . $sku);

        // Próbuj pobrać z cache
        $cached = get_transient($cache_key);

        if ($cached !== false && is_array($cached)) {
            // HIT CACHE! Wynik z cache
            if ($debug && isset($cached['debug_info'])) {
                // Kopiuj debug_info aby nie modyfikować oryginału w cache
                $cached_copy = $cached;
                $cache_header = [
                    'searched' => '📦 Wynik z cache (TTL: 1h)',
                    'query' => 'Brak nowych zapytań do Google Drive API - użyto cache',
                    'strategy' => 'cached',
                    'response_code' => 'cached',
                    'found' => !empty($cached_copy['files']),
                    'cache_key' => substr($cache_key, 0, 20) . '...'
                ];
                array_unshift($cached_copy['debug_info'], $cache_header);
                return $cached_copy;
            }
            return $cached;
        }

        // MISS CACHE - wykonaj wyszukiwanie
        $variations = $this->get_filename_variations($product_name, $sku);
        $data = $this->search_google_drive_file_multiple($variations, true);

        // Dodaj informację że to ŚWIEŻE zapytanie
        if (is_array($data) && isset($data['debug_info'])) {
            $fresh_header = [
                'searched' => '🆕 Nowe wyszukiwanie (zapisano w cache)',
                'query' => 'Wykonano zapytania do Google Drive API - wynik zapisany w cache na 1h',
                'strategy' => 'fresh',
                'response_code' => 'fresh',
                'found' => !empty($data['files']),
                'cache_key' => substr($cache_key, 0, 20) . '...'
            ];
            array_unshift($data['debug_info'], $fresh_header);
        }

        // Zapisz w cache na 1 godzinę
        // Używamy set_transient, który zapisuje w wp_options
        $cache_saved = set_transient($cache_key, $data, 3600);

        // Dodaj info czy cache się zapisało
        if ($debug && is_array($data) && isset($data['debug_info'])) {
            $data['debug_info'][0]['cache_saved'] = $cache_saved ? 'yes' : 'FAILED';
        }

        return $data;
    }

    // MODYFIKACJA 3.4.1 - Sprawdza status pliku używając cache
    private function get_file_status_for_product($product_name, $sku) {
        // Sprawdź memory cache
        $memory_cache_key = $product_name . '|' . $sku;
        if (isset($this->file_status_cache[$memory_cache_key])) {
            return $this->file_status_cache[$memory_cache_key];
        }

        // Użyj cache z database
        $data = $this->get_cached_drive_file($product_name, $sku);
        $status = !empty($data['files']);

        // Zapisz w memory cache
        $this->file_status_cache[$memory_cache_key] = $status;
        return $status;
    }

    // MODYFIKACJA 3.4.1 - Pobiera link używając cache
    private function get_download_link_for_product($product_name, $sku) {
        // Użyj cache z database
        $data = $this->get_cached_drive_file($product_name, $sku);
        if ( ! empty( $data['files'] ) ) return $data['files'][0]['webViewLink'];
        return null;
    }

    // MODYFIKACJA 3.4.3 - Sprawdza czy wszystkie produkty w zamówieniu są TYLKO cyfrowe
    // Jeśli produkt ma "Wersja elektroniczna" + "Wydruk odbiki" to NIE jest tylko cyfrowy!
    private function order_has_only_digital_products($order) {
        $all_digital = true;

        foreach ($order->get_items() as $item_id => $item) {
            $has_electronic_meta = false;
            $has_physical_meta = false;

            // Lista meta które oznaczają produkty fizyczne
            $physical_meta_keys = [
                'wydruk odbiki',
                'wydruk odbitki',
                'karty folio box',
                'karta folio box',
                'opakowanie box',
                'box',
                'pendrive',
                'album',
                'ramka',
                'wydruk',
                'odbitka'
            ];

            foreach ($item->get_formatted_meta_data('_', true) as $meta) {
                $meta_key_lower = strtolower($meta->key);

                if ($meta_key_lower === 'wersja elektroniczna') {
                    $has_electronic_meta = true;
                }

                // Sprawdź czy to meta produktu fizycznego
                foreach ($physical_meta_keys as $physical_key) {
                    if (strpos($meta_key_lower, $physical_key) !== false) {
                        $has_physical_meta = true;
                        break 2; // Wyjdź z obu pętli
                    }
                }
            }

            // Jeśli produkt NIE ma "Wersja elektroniczna" ALBO ma produkty fizyczne
            // to zamówienie nie jest tylko cyfrowe
            if (!$has_electronic_meta || $has_physical_meta) {
                $all_digital = false;
                break;
            }
        }

        return $all_digital;
    }

    public function handle_form_actions() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( isset( $_POST['assign_access'] ) && isset( $_POST['ada_nonce'] ) && wp_verify_nonce( $_POST['ada_nonce'], 'ada_assign_access_action' ) ) {
            if ( empty( $_POST['order_ids'] ) || ! is_array( $_POST['order_ids'] ) ) {
                set_transient( 'ada_admin_notice', [ 'message' => __( 'You did not select any orders.', 'auto-download-access' ), 'type' => 'error' ], 5 );
                return;
            }
            $processed_count = 0;
            foreach ( array_map( 'absint', $_POST['order_ids'] ) as $order_id ) {
                $order = wc_get_order( $order_id );
                if ( ! $order ) continue;
                $email_links_html = $this->generate_links_html_for_order($order);
                if ( empty($email_links_html) ) continue;
                $this->send_access_email( $order, $email_links_html );

                // MODYFIKACJA 3.4.4 - Smart status: completed dla 100% cyfrowych, processing dla mieszanych
                if ($this->order_has_only_digital_products($order)) {
                    // Zamówienie zawiera TYLKO cyfrowe produkty → Zrealizowane
                    $order->update_status( 'completed', __( 'Access to digital photos has been granted.', 'auto-download-access' ) );
                } else {
                    // Zamówienie zawiera też produkty fizyczne → W trakcie realizacji
                    $current_status = $order->get_status();
                    if ($current_status === 'on-hold') {
                        // Zmień z "Wstrzymane" na "W trakcie realizacji"
                        $order->update_status( 'processing', __( 'Access to digital photos has been granted. Physical products pending.', 'auto-download-access' ) );
                    } else {
                        // Inny status - tylko dodaj notatkę
                        $order->add_order_note( __( 'Access to digital photos has been granted. Order contains physical products - status not changed.', 'auto-download-access' ) );
                    }
                }

                $processed_count++;
            }
            if ( $processed_count > 0 ) {
                $message = sprintf( _n( 'Access assigned for %d order.', 'Access assigned for %d orders.', $processed_count, 'auto-download-access' ), $processed_count );
                set_transient( 'ada_admin_notice', [ 'message' => $message, 'type' => 'success' ], 5 );
            }
        }
        if ( isset( $_POST['resend_access'] ) && isset( $_POST['ada_history_nonce'] ) && wp_verify_nonce( $_POST['ada_history_nonce'], 'ada_history_action' ) ) {
            if ( empty( $_POST['order_ids'] ) || ! is_array( $_POST['order_ids'] ) ) {
                set_transient( 'ada_admin_notice', [ 'message' => __( 'You did not select any orders.', 'auto-download-access' ), 'type' => 'error' ], 5 );
                return;
            }
            $processed_count = 0;
            foreach ( array_map( 'absint', $_POST['order_ids'] ) as $order_id ) {
                $order = wc_get_order( $order_id );
                if ( ! $order ) continue;
                $email_links_html = $this->generate_links_html_for_order($order);
                if ( empty($email_links_html) ) continue;
                $this->send_access_email( $order, $email_links_html );
                $order->add_order_note( __( 'Access email resent to the customer.', 'auto-download-access' ) );
                $processed_count++;
            }
            if ( $processed_count > 0 ) {
                $message = sprintf( _n( 'Access email resent for %d order.', 'Access email resent for %d orders.', $processed_count, 'auto-download-access' ), $processed_count );
                set_transient( 'ada_admin_notice', [ 'message' => $message, 'type' => 'success' ], 5 );
            }
        }
    }

    // MODYFIKACJA 3.3.0 - Używa nazwy produktu + SKU do wyszukiwania
    private function generate_links_html_for_order($order) {
        $email_links_html = '<ul>';
        $has_electronic_items = false;
        foreach ( $order->get_items() as $item_id => $item ) {
            foreach ( $item->get_formatted_meta_data( '_', true ) as $meta ) {
                if ( strtolower($meta->key) === 'wersja elektroniczna' ) {
                    $download_link = wc_get_order_item_meta( $item_id, '_ada_manual_file_link', true );
                    if ( empty( $download_link ) ) {
                        $product = $item->get_product();
                        $sku = $product ? $product->get_sku() : '';
                        $product_name = $item->get_name();
                        if ($sku || $product_name) {
                            $download_link = $this->get_download_link_for_product($product_name, $sku);
                        }
                    }
                    if ( ! empty( $download_link ) ) {
                        $email_links_html .= '<li>' . esc_html($item->get_name()) . ': <a href="' . esc_url($download_link) . '">' . __('Download', 'auto-download-access') . '</a></li>';
                        $has_electronic_items = true;
                    }
                }
            }
        }
        $email_links_html .= '</ul>';
        return $has_electronic_items ? $email_links_html : '';
    }

    private function send_access_email( $order, $links_html ) {
        $options = get_option($this->option_name);
        $default_subject = __('Your photos from order #{order_number} are ready!', 'auto-download-access');
        $default_body = __("Hello {customer_name},\n\nThank you for your purchase!\nYour photos are ready to be downloaded. You can use the links below:\n\n{download_links}", 'auto-download-access');
        $subject = !empty($options['email_subject']) ? $options['email_subject'] : $default_subject;
        $body = !empty($options['email_body']) ? $options['email_body'] : $default_body;
        $placeholders = ['{customer_name}' => $order->get_billing_first_name(), '{order_number}' => $order->get_order_number(), '{download_links}' => $links_html];
        $subject = str_replace(array_keys($placeholders), array_values($placeholders), $subject);
        $body = nl2br(str_replace(array_keys($placeholders), array_values($placeholders), $body));
        $mailer = WC()->mailer();
        $recipient = $order->get_billing_email();
        $message = $mailer->wrap_message( $subject, $body );
        $mailer->send( $recipient, $subject, $message );
    }

    public function show_admin_notices() {
        if ( $notice = get_transient( 'ada_admin_notice' ) ) {
            printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $notice['type'] ), esc_html( $notice['message'] ) );
            delete_transient( 'ada_admin_notice' );
        }
    }
    
    public function render_settings_page() {
        $options = get_option( $this->option_name );
        $client_id = $options['google_client_id'] ?? '';
        $is_authorized = ! empty( get_option( $this->standalone_token_option_name ) );
        ?>
        <div class="wrap">
            <h1><?php _e( 'Settings', 'auto-download-access' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( $this->option_name ); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php _e('Google Client ID', 'auto-download-access'); ?></th>
                        <td><input type="text" name="<?php echo $this->option_name; ?>[google_client_id]" value="<?php echo esc_attr( $client_id ); ?>" class="regular-text"/></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e('Google Client Secret', 'auto-download-access'); ?></th>
                        <td><input type="text" name="<?php echo $this->option_name; ?>[google_client_secret]" value="<?php echo esc_attr( $options['google_client_secret'] ?? '' ); ?>" class="regular-text"/></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e('Google Drive Folder ID', 'auto-download-access'); ?></th>
                        <td>
                            <input type="text" name="<?php echo $this->option_name; ?>[google_folder_id]" value="<?php echo esc_attr( $options['google_folder_id'] ?? '' ); ?>" class="regular-text"/>
                            <p class="description"><?php _e('Enter the ID of the main folder in your Google Drive where all customer photos are stored. The plugin will only search within this folder.', 'auto-download-access'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
            <hr/>
            <h2><?php _e('Authorization', 'auto-download-access'); ?></h2>
            <p style="color: <?php echo $is_authorized ? 'green' : 'red'; ?>; font-weight: bold;"><?php echo $is_authorized ? __('Application is authorized.', 'auto-download-access') : __('Status: Not Authorized.', 'auto-download-access'); ?></p>
            <?php if ( ! empty($client_id) ): 
                $redirect_uri = admin_url('admin.php?page=ada-settings');
                $auth_url = 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query(['scope' => 'https://www.googleapis.com/auth/drive.readonly', 'access_type' => 'offline', 'prompt' => 'consent', 'response_type' => 'code', 'redirect_uri' => $redirect_uri, 'client_id' => $client_id]);
            ?>
                <a href="<?php echo esc_url($auth_url); ?>" class="button button-primary"><?php _e('Authorize with Google', 'auto-download-access'); ?></a>
            <?php else: ?>
                <p><?php _e('Please save your Client ID and Secret to enable authorization.', 'auto-download-access'); ?></p>
            <?php endif; ?>
            <div style="margin-top: 40px; padding: 15px; border: 1px solid #c3c4c7; background: #fff;">
                <h3><?php _e('How to Generate Google API Keys', 'auto-download-access'); ?></h3>
                <p><?php _e("<strong>Step 1:</strong> Go to the <a href='https://console.cloud.google.com/apis/dashboard' target='_blank'>Google Cloud Console</a>.", 'auto-download-access'); ?></p>
                <p><?php _e("<strong>Step 2:</strong> Create a new project or select an existing one.", 'auto-download-access'); ?></p>
                <p><?php _e("<strong>Step 3:</strong> In the left sidebar, go to 'APIs & Services' > 'Enabled APIs & services'. Click '+ ENABLE APIS AND SERVICES' and search for 'Google Drive API'. Enable it.", 'auto-download-access'); ?></p>
                <p><?php _e("<strong>Step 4:</strong> Go to 'APIs & Services' > 'OAuth consent screen'. Choose 'External' and create the consent screen. You only need to provide an App name, User support email, and Developer contact information.", 'auto-download-access'); ?></p>
                <p><?php _e("<strong>Step 5:</strong> Go to 'APIs & Services' > 'Credentials'. Click '+ CREATE CREDENTIALS' and select 'OAuth client ID'.", 'auto-download-access'); ?></p>
                <p><?php _e("<strong>Step 6:</strong> Select 'Web application' as the application type. Under 'Authorized redirect URIs', click '+ ADD URI' and enter the following URL:", 'auto-download-access'); ?> <code><?php echo esc_url(admin_url('admin.php?page=ada-settings')); ?></code></p>
                <p><?php _e("<strong>Step 7:</strong> Click 'Create'. Your Client ID and Client Secret will be displayed. Copy and paste them into the fields above.", 'auto-download-access'); ?></p>
            </div>
            <hr style="margin-top: 40px;">
            <h2><?php _e('Cache Management', 'auto-download-access'); ?></h2>
            <p><?php _e('File search results are cached for 1 hour to improve performance. If you uploaded new files to Google Drive or renamed existing files, clear the cache to see fresh results.', 'auto-download-access'); ?></p>
            <form method="post" action="">
                <?php wp_nonce_field( 'ada_clear_cache_nonce_action', 'ada_clear_cache_nonce' ); ?>
                <input type="submit" name="ada_clear_cache" class="button button-secondary" value="<?php _e('Clear File Cache', 'auto-download-access'); ?>">
            </form>
            <hr style="margin-top: 40px;">
            <h2 style="color: #d63638;"><?php _e('Danger Zone', 'auto-download-access'); ?></h2>
            <form method="post" action="">
                <?php wp_nonce_field( 'ada_reset_nonce_action', 'ada_reset_nonce' ); ?>
                <input type="submit" name="ada_reset_settings" class="button button-secondary" style="color: #d63638; border-color: #d63638;" value="<?php _e('Reset and Clear All Settings', 'auto-download-access'); ?>" onclick="return confirm('<?php _e('Are you sure you want to delete all settings? This cannot be undone.', 'auto-download-access'); ?>');">
            </form>
        </div>
        <?php
    }

    public function render_email_template_page() {
        $options = get_option( $this->option_name );
        $email_subject = $options['email_subject'] ?? __('Your photos from order #{order_number} are ready!', 'auto-download-access');
        $email_body = $options['email_body'] ?? __("Hello {customer_name},\n\nThank you for your purchase!\nYour photos are ready to be downloaded. You can use the links below:\n\n{download_links}", 'auto-download-access');
        ?>
        <div class="wrap">
            <h1><?php _e('Email Templates', 'auto-download-access'); ?></h1>
            <p><?php _e('Customize the email that is sent to customers when their photos are ready.', 'auto-download-access'); ?></p>
            <form method="post" action="options.php">
                <?php settings_fields( $this->option_name ); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php _e('Email Subject', 'auto-download-access'); ?></th>
                        <td><input type="text" name="<?php echo $this->option_name; ?>[email_subject]" value="<?php echo esc_attr( $email_subject ); ?>" class="regular-text"/></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e('Email Body', 'auto-download-access'); ?></th>
                        <td>
                            <textarea name="<?php echo $this->option_name; ?>[email_body]" rows="10" class="large-text"><?php echo esc_textarea( $email_body ); ?></textarea>
                            <p class="description"><?php _e('Available placeholders: {customer_name}, {order_number}, {download_links}', 'auto-download-access'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    // MODYFIKACJA 3.1.1 - Dodanie atrybutów data- do przycisków "Nie znaleziono"
    public function render_admin_page() {
        ?>
        <style>
            .ada-table { width: 100%; border-collapse: collapse; margin-top: 20px; } .ada-table th, .ada-table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #e5e5e5; vertical-align: top; } .ada-table .order-items .item-meta { display: block; font-size: 0.85em; color: #777; } .ada-table .order-items .file-status { display: inline-block; margin-left: 8px; font-weight: bold; font-size: 0.9em; } .file-status.detected, .file-status.manual { color: #228B22; } .file-status.not-found { color: #DC143C; } .searched-for-filename { font-size: 0.8em; color: #999; display: block; } .item-thumbnail { float: left; margin-right: 10px; width: 48px; height: 48px; object-fit: cover; }
            .ada-filters { margin: 20px 0; padding: 15px; background: #fff; border: 1px solid #c3c4c7; } .ada-filters label { margin-right: 10px; vertical-align: middle; } .ada-filters input[type="date"], .ada-filters input[type="text"] { margin-right: 20px; vertical-align: middle; } .ada-filters .button { margin-right: 10px; vertical-align: middle; }
            .ada-open-picker { margin-right: 5px !important; } 
            .ada-disconnect-link { margin-left: 10px; color: #d63638 !important; vertical-align: middle; text-decoration: underline; cursor: pointer; } 
        </style>
        <div class="wrap">
            <h1><?php _e( 'Assign Access', 'auto-download-access' ); ?></h1>
            <form method="GET" class="ada-filters">
                <input type="hidden" name="page" value="ada-assign-access">
                <label for="date_from"><?php _e('From', 'auto-download-access'); ?>:</label>
                <input type="date" id="date_from" name="date_from" value="<?php echo isset($_GET['date_from']) ? esc_attr($_GET['date_from']) : ''; ?>">
                <label for="date_to"><?php _e('To', 'auto-download-access'); ?>:</label>
                <input type="date" id="date_to" name="date_to" value="<?php echo isset($_GET['date_to']) ? esc_attr($_GET['date_to']) : ''; ?>">
                <label for="sku_search"><?php _e('Search by SKU', 'auto-download-access'); ?>:</label>
                <input type="text" id="sku_search" name="sku_search" value="<?php echo isset($_GET['sku_search']) ? esc_attr($_GET['sku_search']) : ''; ?>">
                <button type="submit" class="button"><?php _e('Filter', 'auto-download-access'); ?></button>
                <a href="<?php echo admin_url('admin.php?page=ada-assign-access'); ?>" class="button button-secondary"><?php _e('Clear', 'auto-download-access'); ?></a>
            </form>
            <form method="POST" action="">
                <?php wp_nonce_field( 'ada_assign_access_action', 'ada_nonce' ); ?>
                <table class="widefat fixed striped ada-table">
                    <thead>
                        <tr>
                            <th class="check-column"><input type="checkbox" id="cb-select-all"></th>
                            <th><?php _e( 'Order', 'auto-download-access' ); ?></th>
                            <th><?php _e( 'Customer', 'auto-download-access' ); ?></th>
                            <th><?php _e( 'Date', 'auto-download-access' ); ?></th>
                            <th><?php _e( 'Status', 'auto-download-access' ); ?></th>
                            <th><?php _e( 'Items / Detected images', 'auto-download-access' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $args = ['status' => ['processing', 'on-hold'], 'limit' => -1, 'orderby' => 'date', 'order' => 'DESC'];
                        if (!empty($_GET['date_from']) && !empty($_GET['date_to'])) {
                            $args['date_query'] = [[ 'after' => sanitize_text_field($_GET['date_from']), 'before' => sanitize_text_field($_GET['date_to']), 'inclusive' => true, ]];
                        }
                        $orders = wc_get_orders($args);
                        $sku_search = isset($_GET['sku_search']) ? sanitize_text_field(trim($_GET['sku_search'])) : '';
                        $found_orders = false;
                        foreach ( $orders as $order ) {
                            $electronic_items = [];
                            $order_has_sku = empty($sku_search); 
                            $sku_list = []; 
                            foreach ( $order->get_items() as $item_id => $item ) {
                                foreach ( $item->get_formatted_meta_data( '_', true ) as $meta ) {
                                    if ( strtolower($meta->key) === 'wersja elektroniczna' ) {
                                        $product = $item->get_product();
                                        $sku = $product ? $product->get_sku() : '';
                                        $sku_list[] = $sku;
                                        $product_name = $item->get_name();
                                        $manual_link = wc_get_order_item_meta( $item_id, '_ada_manual_file_link', true );
                                        $file_status = false;
                                        $debug_info = null;
                                        if (empty($manual_link)) {
                                            // MODYFIKACJA 3.4.2 - Używamy cache z debug info
                                            $search_result = $this->get_cached_drive_file($product_name, $sku, true);
                                            $file_status = !empty($search_result['files']);
                                            $debug_info = $search_result['debug_info'] ?? null;
                                        }
                                        $electronic_items[] = ['name' => $product_name, 'sku' => $sku ?? '', 'status' => $file_status, 'manual_link' => $manual_link, 'item_id' => $item_id, 'thumbnail' => $product ? $product->get_image('thumbnail', ['class' => 'item-thumbnail']) : '', 'debug_info' => $debug_info];
                                    }
                                }
                            }
                            if ( empty($electronic_items) ) continue;
                            if (!empty($sku_search)) {
                                $order_has_sku = false; 
                                foreach ($sku_list as $sku) {
                                    if (!empty($sku) && stripos($sku, $sku_search) !== false) {
                                        $order_has_sku = true;
                                        break; 
                                    }
                                }
                            }
                            if ( !$order_has_sku ) continue;
                            $found_orders = true;
                            ?>
                                <tr>
                                    <th class="check-column"><input type="checkbox" name="order_ids[]" value="<?php echo $order->get_id(); ?>"></th>
                                    <td><a href="<?php echo $order->get_edit_order_url(); ?>" target="_blank">#<?php echo $order->get_order_number(); ?></a></td>
                                    <td><?php echo $order->get_formatted_billing_full_name(); ?></td>
                                    <td><?php echo wc_format_datetime( $order->get_date_created() ); ?></td>
                                    <td><?php echo wc_get_order_status_name( $order->get_status() ); ?></td>
                                    <td class="order-items">
                                        <?php foreach ($electronic_items as $e_item): ?>
                                            <div style="margin-bottom: 15px; clear: both;">
                                                <?php echo $e_item['thumbnail']; ?>
                                                <strong><?php echo esc_html($e_item['name']); ?></strong>
                                                <div class="item-status-container" data-item-id="<?php echo $e_item['item_id']; ?>">
                                                    <?php
                                                    // MODYFIKACJA 3.3.0 - Pokazujemy pełną listę prób wyszukiwania
                                                    $search_variations = $this->get_filename_variations($e_item['name'], $e_item['sku']);
                                                    $primary_search = !empty($search_variations) ? $search_variations[0] : $e_item['sku'];
                                                    ?>
                                                    <?php if (!empty($e_item['manual_link'])): ?>
                                                        <span class="file-status manual">&#9679; <?php _e('Manually Linked', 'auto-download-access'); ?></span>
                                                        <button type="button" class="button-link ada-disconnect-link"
                                                                data-item-id="<?php echo $e_item['item_id']; ?>"
                                                                data-sku="<?php echo esc_attr($e_item['sku']); ?>"
                                                                data-searched-file="<?php echo esc_attr($primary_search . '.jpg'); ?>">
                                                            <?php _e('Disconnect', 'auto-download-access'); ?>
                                                        </button>
                                                    <?php elseif ($e_item['status']): ?>
                                                        <span class="file-status detected">&#9679; <?php _e('Detected', 'auto-download-access'); ?></span>
                                                        <button type="button" class="button-link ada-change-detected-link"
                                                                data-item-id="<?php echo $e_item['item_id']; ?>"
                                                                data-sku="<?php echo esc_attr($e_item['sku']); ?>"
                                                                data-searched-file="<?php echo esc_attr($primary_search . '.jpg'); ?>"
                                                                style="margin-left: 10px; color: #2271b1; vertical-align: middle; text-decoration: underline; cursor: pointer;">
                                                            <?php _e('Change', 'auto-download-access'); ?>
                                                        </button>
                                                        <div class="ada-change-buttons" style="display: none; margin-top: 8px;">
                                                            <button type="button" class="button button-secondary ada-open-picker"
                                                                    data-item-id="<?php echo $e_item['item_id']; ?>"
                                                                    data-sku="<?php echo esc_attr($e_item['sku']); ?>"
                                                                    data-searched-file="<?php echo esc_attr($primary_search . '.jpg'); ?>">
                                                                <?php _e('Choose from Drive', 'auto-download-access'); ?>
                                                            </button>
                                                            <button type="button" class="button button-secondary ada-manual-link"
                                                                    data-item-id="<?php echo $e_item['item_id']; ?>"
                                                                    data-sku="<?php echo esc_attr($e_item['sku']); ?>"
                                                                    data-searched-file="<?php echo esc_attr($primary_search . '.jpg'); ?>">
                                                                <?php _e('Paste link manually', 'auto-download-access'); ?>
                                                            </button>
                                                            <button type="button" class="button button-secondary ada-cancel-change"
                                                                    data-item-id="<?php echo $e_item['item_id']; ?>"
                                                                    style="margin-left: 10px;">
                                                                <?php _e('Cancel', 'auto-download-access'); ?>
                                                            </button>
                                                        </div>
                                                    <?php else: ?>
                                                        <span class="file-status not-found">&#9679; <?php _e('Not Found', 'auto-download-access'); ?></span>
                                                        <span class="searched-for-filename"><?php printf(__('(SKU: %s) Searched for: %s', 'auto-download-access'), esc_html($e_item['sku']), esc_html($primary_search . '.jpg')); ?></span>
                                                        <?php if (!empty($e_item['debug_info'])): ?>
                                                            <details style="margin-top: 8px; padding: 8px; background: #f0f0f1; border-radius: 4px; font-size: 11px;" open>
                                                                <summary style="cursor: pointer; font-weight: bold; color: #2271b1;">🔍 Szczegóły wyszukiwania (<?php echo count($e_item['debug_info']); ?> prób)</summary>
                                                                <div style="margin-top: 8px; padding-left: 10px;">
                                                                    <?php foreach ($e_item['debug_info'] as $idx => $debug): ?>
                                                                        <div style="margin-bottom: 8px; padding: 8px; background: white; border-left: 3px solid <?php echo $debug['found'] ? '#46b450' : '#dc3232'; ?>; border-radius: 2px;">
                                                                            <div style="margin-bottom: 4px;">
                                                                                <strong><?php echo ($idx + 1); ?>.</strong>
                                                                                <code style="background: #f6f7f7; padding: 2px 6px; border-radius: 3px;"><?php echo esc_html($debug['searched']); ?></code>
                                                                                <?php if (!empty($debug['strategy'])): ?>
                                                                                    <span style="background: #e0e0e0; padding: 1px 4px; border-radius: 2px; font-size: 9px; margin-left: 4px;"><?php echo esc_html($debug['strategy']); ?></span>
                                                                                <?php endif; ?>
                                                                                <?php if ($debug['found']): ?>
                                                                                    <span style="color: #46b450; font-weight: bold;">✓ ZNALEZIONO</span>
                                                                                <?php else: ?>
                                                                                    <span style="color: #dc3232;">✗ nie znaleziono</span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                            <div style="font-size: 10px; color: #666; margin-top: 4px;">
                                                                                <div>Response: <code><?php echo esc_html($debug['response_code'] ?? 'N/A'); ?></code></div>
                                                                                <?php if (!empty($debug['cache_key'])): ?>
                                                                                    <div>Cache key: <code><?php echo esc_html($debug['cache_key']); ?></code></div>
                                                                                <?php endif; ?>
                                                                                <?php if (isset($debug['cache_saved'])): ?>
                                                                                    <div style="<?php echo $debug['cache_saved'] === 'yes' ? 'color: #46b450;' : 'color: #dc3232; font-weight: bold;'; ?>">
                                                                                        Cache saved: <code><?php echo esc_html($debug['cache_saved']); ?></code>
                                                                                    </div>
                                                                                <?php endif; ?>
                                                                                <?php if (!empty($debug['found_file'])): ?>
                                                                                    <div>Found: <code><?php echo esc_html($debug['found_file']); ?></code></div>
                                                                                <?php endif; ?>
                                                                                <?php if (!empty($debug['query'])): ?>
                                                                                    <details style="margin-top: 2px;">
                                                                                        <summary style="cursor: pointer; color: #2271b1;">Pokaż query</summary>
                                                                                        <code style="display: block; background: #f6f7f7; padding: 4px; margin-top: 2px; word-break: break-all; font-size: 9px;"><?php echo esc_html($debug['query']); ?></code>
                                                                                    </details>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>
                                                                    <?php endforeach; ?>
                                                                </div>
                                                            </details>
                                                        <?php endif; ?>
                                                        <button type="button" class="button button-secondary ada-open-picker"
                                                                data-item-id="<?php echo $e_item['item_id']; ?>"
                                                                data-sku="<?php echo esc_attr($e_item['sku']); ?>"
                                                                data-searched-file="<?php echo esc_attr($primary_search . '.jpg'); ?>">
                                                            <?php _e('Choose from Drive', 'auto-download-access'); ?>
                                                        </button>
                                                        <button type="button" class="button button-secondary ada-manual-link"
                                                                data-item-id="<?php echo $e_item['item_id']; ?>"
                                                                data-sku="<?php echo esc_attr($e_item['sku']); ?>"
                                                                data-searched-file="<?php echo esc_attr($primary_search . '.jpg'); ?>">
                                                            <?php _e('Paste link manually', 'auto-download-access'); ?>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </td>
                                </tr>
                                <?php
                        }
                        if ( ! $found_orders ) {
                            echo '<tr><td colspan="6">' . __( 'No orders requiring access assignment found.', 'auto-download-access' ) . '</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
                <?php if ($found_orders): ?>
                <div class="tablenav bottom"><div class="alignleft actions">
                    <input type="submit" name="assign_access" class="button button-primary" value="<?php _e( 'Assign Access & Send Email', 'auto-download-access' ); ?>">
                </div></div>
                <?php endif; ?>
            </form>
        </div>
        <script>jQuery(document).ready(function($){$('#cb-select-all').on('click', function(){$('input[name="order_ids[]"]').prop('checked', this.checked);});});</script>
        <?php
    }

    public function render_history_page() {
        ?>
        <style>
            .ada-table { width: 100%; border-collapse: collapse; margin-top: 20px; } .ada-table th, .ada-table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #e5e5e5; vertical-align: top; } .ada-table .order-items .item-meta { display: block; font-size: 0.85em; color: #777; } .item-thumbnail { float: left; margin-right: 10px; width: 48px; height: 48px; object-fit: cover; }
            .ada-filters { margin: 20px 0; padding: 15px; background: #fff; border: 1px solid #c3c4c7; } .ada-filters label { margin-right: 10px; vertical-align: middle; } .ada-filters input[type="date"], .ada-filters input[type="text"] { margin-right: 20px; vertical-align: middle; } .ada-filters .button { margin-right: 10px; vertical-align: middle; }
        </style>
        <div class="wrap">
            <h1><?php _e( 'Access History', 'auto-download-access' ); ?></h1>
            <form method="GET" class="ada-filters">
                <input type="hidden" name="page" value="ada-history">
                <label for="date_from"><?php _e('From', 'auto-download-access'); ?>:</label>
                <input type="date" id="date_from" name="date_from" value="<?php echo isset($_GET['date_from']) ? esc_attr($_GET['date_from']) : ''; ?>">
                <label for="date_to"><?php _e('To', 'auto-download-access'); ?>:</label>
                <input type="date" id="date_to" name="date_to" value="<?php echo isset($_GET['date_to']) ? esc_attr($_GET['date_to']) : ''; ?>">
                <label for="sku_search"><?php _e('Search by SKU', 'auto-download-access'); ?>:</label>
                <input type="text" id="sku_search" name="sku_search" value="<?php echo isset($_GET['sku_search']) ? esc_attr($_GET['sku_search']) : ''; ?>">
                <button type="submit" class="button"><?php _e('Filter', 'auto-download-access'); ?></button>
                <a href="<?php echo admin_url('admin.php?page=ada-history'); ?>" class="button button-secondary"><?php _e('Clear', 'auto-download-access'); ?></a>
            </form>
            <form method="POST" action="">
                <?php wp_nonce_field( 'ada_history_action', 'ada_history_nonce' ); ?>
                <table class="widefat fixed striped ada-table">
                    <thead>
                        <tr>
                            <th class="check-column"><input type="checkbox" id="cb-select-all"></th>
                            <th><?php _e( 'Order', 'auto-download-access' ); ?></th>
                            <th><?php _e( 'Customer', 'auto-download-access' ); ?></th>
                            <th><?php _e( 'Date Completed', 'auto-download-access' ); ?></th>
                            <th><?php _e( 'Items', 'auto-download-access' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $args = ['status' => ['completed'], 'limit' => -1, 'orderby' => 'date', 'order' => 'DESC'];
                        if (!empty($_GET['date_from']) && !empty($_GET['date_to'])) {
                            $args['date_query'] = [[ 'after' => sanitize_text_field($_GET['date_from']) . ' 00:00:00', 'before' => sanitize_text_field($_GET['date_to']) . ' 23:59:59', 'inclusive' => true, 'column' => 'post_date' ]];
                        }
                        $orders = wc_get_orders($args);
                        $sku_search = isset($_GET['sku_search']) ? sanitize_text_field(trim($_GET['sku_search'])) : '';
                        $found_orders = false;
                        foreach ( $orders as $order ) {
                            $electronic_items = [];
                            $order_has_sku = empty($sku_search); 
                            $sku_list = [];
                            foreach ( $order->get_items() as $item_id => $item ) {
                                foreach ( $item->get_formatted_meta_data( '_', true ) as $meta ) {
                                    if ( strtolower($meta->key) === 'wersja elektroniczna' ) {
                                        $product = $item->get_product();
                                        $sku = $product ? $product->get_sku() : '';
                                        $sku_list[] = $sku;
                                        $electronic_items[] = ['name' => $item->get_name(), 'thumbnail' => $product ? $product->get_image('thumbnail', ['class' => 'item-thumbnail']) : ''];
                                    }
                                }
                            }
                            if ( empty($electronic_items) ) continue;
                            if (!empty($sku_search)) {
                                $order_has_sku = false;
                                foreach ($sku_list as $sku) {
                                    if (!empty($sku) && stripos($sku, $sku_search) !== false) {
                                        $order_has_sku = true;
                                        break;
                                    }
                                }
                            }
                            if ( !$order_has_sku ) continue;
                            $found_orders = true;
                            ?>
                                <tr>
                                    <th class="check-column"><input type="checkbox" name="order_ids[]" value="<?php echo $order->get_id(); ?>"></th>
                                    <td><a href="<?php echo $order->get_edit_order_url(); ?>" target="_blank">#<?php echo $order->get_order_number(); ?></a></td>
                                    <td><?php echo $order->get_formatted_billing_full_name(); ?></td>
                                    <td><?php echo wc_format_datetime( $order->get_date_completed() ); ?></td>
                                    <td class="order-items">
                                        <?php foreach ($electronic_items as $e_item): ?>
                                            <div style="margin-bottom: 10px; clear:both;"><?php echo $e_item['thumbnail']; ?> <strong><?php echo esc_html($e_item['name']); ?></strong></div>
                                        <?php endforeach; ?>
                                    </td>
                                </tr>
                                <?php
                        }
                        if ( ! $found_orders ) {
                            echo '<tr><td colspan="5">' . __( 'No completed orders with digital products found.', 'auto-download-access' ) . '</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
                <?php if ($found_orders): ?>
                <div class="tablenav bottom"><div class="alignleft actions">
                    <input type="submit" name="resend_access" class="button button-primary" value="<?php _e( 'Resend Access & Send Email', 'auto-download-access' ); ?>">
                </div></div>
                <?php endif; ?>
            </form>
        </div>
        <script>jQuery(document).ready(function($){$('#cb-select-all').on('click', function(){$('input[name="order_ids[]"]').prop('checked', this.checked);});});</script>
        <?php
    }
}

function run_auto_download_access() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="error"><p><strong>' . esc_html__( 'Photo Access', 'auto-download-access' ) . '</strong>: ' . esc_html__( 'This plugin requires WooCommerce to be activated.', 'auto-download-access' ) . '</p></div>';
        });
        return;
    }
    new Auto_Download_access();
}
add_action( 'plugins_loaded', 'run_auto_download_access' );

// MODYFIKACJA 3.4.3 - Activation hook dla flush rewrite rules (My Account endpoint)
function ada_activation_hook() {
    // Flush rewrite rules aby My Account endpoint działał
    add_rewrite_endpoint( 'photo-downloads', EP_ROOT | EP_PAGES );
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'ada_activation_hook' );

// MODYFIKACJA 3.4.3 - Deactivation hook
function ada_deactivation_hook() {
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'ada_deactivation_hook' );