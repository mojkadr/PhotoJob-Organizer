(function($) {
    'use strict';

    let pickerApiLoaded = false;
    let oauthToken;
    let currentItemId;

    /**
     * Ta funkcja jest teraz wywoływana globalnie przez skrypt Google API
     * po jego załadowaniu (dzięki ?onload=adaOnGoogleApiLoad w PHP).
     */
    window.adaOnGoogleApiLoad = function() {
        gapi.load('picker', function() {
            pickerApiLoaded = true;
        });
        gapi.load('auth2', function() {
            if (ada_picker_vars.accessToken) {
                oauthToken = ada_picker_vars.accessToken;
            }
        });
    }

    function createPicker() {
        if (!pickerApiLoaded || !oauthToken) {
            console.error("Picker API not loaded or no OAuth token.");

            if (typeof gapi !== 'undefined') {
                 if (!pickerApiLoaded) gapi.load('picker', function() { pickerApiLoaded = true; });
                 if (!oauthToken) gapi.load('auth2', function() { if (ada_picker_vars.accessToken) oauthToken = ada_picker_vars.accessToken; });
            }

            alert("Nie można zainicjować Google Drive Picker. Odśwież stronę lub spróbuj ponownie za chwilę.");
            return;
        }

        // MODYFIKACJA 3.3.9 - Poprawiona konfiguracja Google Picker
        const docsView = new google.picker.DocsView(google.picker.ViewId.DOCS_IMAGES)
            .setMimeTypes("image/jpeg,image/jpg,image/png,image/avif,image/webp")
            .setMode(google.picker.DocsViewMode.GRID);

        // Jeśli folder ID jest określony, ustaw go jako parent
        if (ada_picker_vars.folderId && ada_picker_vars.folderId.trim() !== '') {
            docsView.setParent(ada_picker_vars.folderId);
            docsView.setIncludeFolders(false); // Ukryj podfoldery
        }

        const picker = new google.picker.PickerBuilder()
            .setAppId(ada_picker_vars.clientId.split('.')[0])
            .setOAuthToken(oauthToken)
            .addView(docsView)
            .setCallback(pickerCallback)
            .setTitle('Wybierz zdjęcie')
            .setSize(1050, 650)
            .build();
        picker.setVisible(true);
    }

    function pickerCallback(data) {
        if (data.action === google.picker.Action.PICKED) {
            const file = data.docs[0];
            const fileUrl = file.url; 
            saveManualLink(fileUrl);
        }
    }

    /**
     * Funkcja do zapisu linku przez AJAX
     */
    function saveManualLink(fileUrl) {
        const $container = $('.item-status-container[data-item-id="' + currentItemId + '"]');
        // Spróbuj pobrać dane z przycisków, które kliknęliśmy (lub ich rodzeństwa)
        let $sourceButton = $('.ada-open-picker[data-item-id="' + currentItemId + '"]');
        if (!$sourceButton.length) {
            $sourceButton = $('.ada-manual-link[data-item-id="' + currentItemId + '"]');
        }
        
        const sku = $sourceButton.data('sku') || '';
        const searchedFile = $sourceButton.data('searched-file') || '';

        $.ajax({
            url: ada_picker_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'ada_save_manual_link',
                nonce: ada_picker_vars.nonce,
                item_id: currentItemId,
                file_url: fileUrl
            },
            success: function(response) {
                if (response.success) {
                    // Odtwórz HTML "Powiązano ręcznie" z przyciskiem "Odłącz"
                    const html = `
                        <span class="file-status manual">&#9679; ${ada_picker_vars.linkSaved}</span>
                        <button type="button" class="button-link ada-disconnect-link" 
                                data-item-id="${currentItemId}"
                                data-sku="${sku}"
                                data-searched-file="${searchedFile}">
                            ${ada_picker_vars.disconnect}
                        </button>
                    `;
                    $container.html(html);

                } else {
                    alert('Error saving link: ' + (response.data.message || 'Unknown error'));
                }
            },
            error: function() {
                alert('An unknown error occurred while saving the link.');
            }
        });
    }

    // Handler dla Google Drive Picker
    $(document).on('click', '.ada-open-picker', function(e) {
        e.preventDefault();
        currentItemId = $(this).data('item-id');
        createPicker();
    });

    // Handler dla przycisku "Wklej link ręcznie"
    $(document).on('click', '.ada-manual-link', function(e) {
        e.preventDefault();
        currentItemId = $(this).data('item-id'); 

        const fileUrl = prompt(ada_picker_vars.pasteUrlPrompt);

        if (fileUrl && fileUrl.trim() !== '') {
            if (!fileUrl.startsWith('http://') && !fileUrl.startsWith('https://')) {
                alert(ada_picker_vars.invalidUrl);
                return;
            }
            saveManualLink(fileUrl.trim());
        }
    });

    /**
     * Handler dla przycisku "Odłącz"
     */
    $(document).on('click', '.ada-disconnect-link', function(e) {
        e.preventDefault();
        const $button = $(this);
        const itemId = $button.data('item-id');
        const sku = $button.data('sku');
        const searchedFile = $button.data('searched-file');
        const $container = $button.closest('.item-status-container');

        $.ajax({
            url: ada_picker_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'ada_disconnect_manual_link',
                nonce: ada_picker_vars.nonce,
                item_id: itemId
            },
            success: function(response) {
                if (response.success) {
                    // Odbuduj stan "Nie znaleziono"
                    const searchedForText = (ada_picker_vars.searchedFor).replace('%s', sku).replace('%s', searchedFile);

                    const html = `
                        <span class="file-status not-found">&#9679; ${ada_picker_vars.notFound}</span>
                        <span class="searched-for-filename">${searchedForText}</span>
                        <button type="button" class="button button-secondary ada-open-picker"
                                data-item-id="${itemId}"
                                data-sku="${sku}"
                                data-searched-file="${searchedFile}">
                            ${ada_picker_vars.chooseFromDrive}
                        </button>
                        <button type="button" class="button button-secondary ada-manual-link"
                                data-item-id="${itemId}"
                                data-sku="${sku}"
                                data-searched-file="${searchedFile}">
                            ${ada_picker_vars.pasteManually}
                        </button>
                    `;
                    $container.html(html);
                } else {
                    alert('Error disconnecting link: ' + (response.data.message || 'Unknown error'));
                }
            },
            error: function() {
                alert('An unknown error occurred while disconnecting the link.');
            }
        });
    });

    /**
     * Handler dla przycisku "Zmień" przy automatycznie wykrytych plikach
     */
    $(document).on('click', '.ada-change-detected-link', function(e) {
        e.preventDefault();
        const $button = $(this);
        const $container = $button.closest('.item-status-container');

        // Ukryj przycisk "Zmień" i pokaż przyciski akcji
        $button.hide();
        $container.find('.ada-change-buttons').slideDown(200);
    });

    /**
     * Handler dla przycisku "Anuluj" (ukrywa przyciski zmiany)
     */
    $(document).on('click', '.ada-cancel-change', function(e) {
        e.preventDefault();
        const $button = $(this);
        const $container = $button.closest('.item-status-container');

        // Ukryj przyciski akcji i pokaż przycisk "Zmień"
        $container.find('.ada-change-buttons').slideUp(200);
        $container.find('.ada-change-detected-link').show();
    });

})(jQuery);