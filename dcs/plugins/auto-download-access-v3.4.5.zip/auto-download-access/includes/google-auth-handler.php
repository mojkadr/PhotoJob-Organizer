
<?php
if (!defined('ABSPATH')) exit;

function ada_handle_google_auth() {
    if (isset($_GET['code'])) {
        $client = ada_get_google_client();
        $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);

        if (!isset($token['error'])) {
            update_option('ada_google_token', $token);
            if (isset($token['refresh_token'])) {
                update_option('ada_google_refresh_token_single', $token['refresh_token']);
            }
        } else {
            // Handle error
        }
    }
    wp_redirect(admin_url('admin.php?page=ada-settings'));
    exit();
}
