
<?php
if (!defined('ABSPATH')) exit;

function ada_render_settings_page() {
    if (isset($_POST['ada_settings_nonce']) && wp_verify_nonce($_POST['ada_settings_nonce'], 'ada_save_settings')) {
        $existing_credentials = get_option('ada_google_credentials', ['client_id' => '', 'client_secret' => '']);

        // Update Client ID
        $client_id = sanitize_text_field($_POST['ada_google_client_id']);

        // Only update Client Secret if a new value was provided (for security)
        $client_secret_input = sanitize_text_field($_POST['ada_google_client_secret']);
        $client_secret = !empty($client_secret_input) ? $client_secret_input : $existing_credentials['client_secret'];

        $credentials = [
            'client_id' => $client_id,
            'client_secret' => $client_secret,
        ];
        update_option('ada_google_credentials', $credentials);

        $settings = [
            'gdrive_folder_id' => sanitize_text_field($_POST['ada_gdrive_folder_id']),
        ];
        update_option('ada_settings', $settings);

        echo '<div class="notice notice-success is-dismissible"><p>' . __('Settings saved.', 'auto-download-access') . '</p></div>';
    }

    if (isset($_POST['ada_reset_nonce']) && wp_verify_nonce($_POST['ada_reset_nonce'], 'ada_reset_action')) {
        delete_option('ada_google_credentials');
        delete_option('ada_google_token');
        delete_option('ada_google_refresh_token_single');
        delete_option('ada_settings');
        echo '<div class="notice notice-success is-dismissible"><p>' . __('All settings and authorization have been cleared.', 'auto-download-access') . '</p></div>';
    }

    $credentials = get_option('ada_google_credentials', ['client_id' => '', 'client_secret' => '']);
    $settings = get_option('ada_settings', ['gdrive_folder_id' => '']);
    $client = ada_get_google_client();
    $is_authorized = $client->getAccessToken() && !$client->isAccessTokenExpired();
    ?>
    <div class="wrap ada-wrap">
        <h1><?php _e('ADA - Settings', 'auto-download-access'); ?></h1>

        <div id="ada-gdrive-browser-modal" style="display:none;">
            <div class="ada-modal-content">
                <div class="ada-modal-header">
                    <h2><?php _e('Browse Google Drive', 'auto-download-access'); ?></h2>
                    <button type="button" class="ada-modal-close">&times;</button>
                </div>
                <div class="ada-modal-body">
                    <div id="ada-gdrive-browser-content"></div>
                </div>
                <div class="ada-modal-footer">
                    <button type="button" id="ada-select-folder-button" class="button button-primary"><?php _e('Select Current Folder', 'auto-download-access'); ?></button>
                </div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field('ada_save_settings', 'ada_settings_nonce'); ?>
            <h2><?php _e('Google API Credentials', 'auto-download-access'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="ada_google_client_id"><?php _e('Client ID', 'auto-download-access'); ?></label></th>
                    <td><input type="text" id="ada_google_client_id" name="ada_google_client_id" value="<?php echo esc_attr($credentials['client_id']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="ada_google_client_secret"><?php _e('Client Secret', 'auto-download-access'); ?></label></th>
                    <td>
                        <input
                            type="password"
                            id="ada_google_client_secret"
                            name="ada_google_client_secret"
                            value=""
                            class="regular-text"
                            autocomplete="new-password"
                            data-lpignore="true"
                            placeholder="<?php echo !empty($credentials['client_secret']) ? __('••••••••••••••••', 'auto-download-access') : __('Enter Client Secret', 'auto-download-access'); ?>">
                        <?php if (!empty($credentials['client_secret'])) : ?>
                            <p class="description" style="color: #46b450;">
                                ✓ <?php _e('Client Secret is saved (leave empty to keep current)', 'auto-download-access'); ?>
                            </p>
                        <?php else : ?>
                            <p class="description"><?php _e('Enter your Google API Client Secret', 'auto-download-access'); ?></p>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

            <h2><?php _e('Google Drive Settings', 'auto-download-access'); ?></h2>
            <table class="form-table">
                 <tr>
                    <th scope="row"><label for="ada_gdrive_folder_id"><?php _e('Main Folder ID', 'auto-download-access'); ?></label></th>
                    <td>
                        <input type="text" id="ada_gdrive_folder_id" name="ada_gdrive_folder_id" value="<?php echo esc_attr($settings['gdrive_folder_id']); ?>" class="regular-text">
                        <button type="button" id="ada-browse-gdrive-button" class="button" <?php echo !$is_authorized ? 'disabled' : ''; ?>><?php _e('Browse', 'auto-download-access'); ?></button>
                        <p class="description"><?php _e('Specify the ID of the main Google Drive folder where all order subfolders are located. Leave empty to search the entire Drive.', 'auto-download-access'); ?></p>
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>

        <h2><?php _e('Authorization', 'auto-download-access'); ?></h2>
        <p><?php _e('Status:', 'auto-download-access'); ?> 
            <?php if ($is_authorized) : ?>
                <strong style="color: green;"><?php _e('Authorized', 'auto-download-access'); ?></strong>
            <?php else : ?>
                <strong style="color: red;"><?php _e('Not Authorized', 'auto-download-access'); ?></strong>
            <?php endif; ?>
        </p>
        <?php
        if (!empty($credentials['client_id']) && !empty($credentials['client_secret'])) {
            $authUrl = $client->createAuthUrl();
            echo '<a href="' . esc_url($authUrl) . '" class="button button-primary">' . ($is_authorized ? __('Re-authorize', 'auto-download-access') : __('Authorize with Google', 'auto-download-access')) . '</a>';
        } else {
            echo '<p>' . __('Please enter your Client ID and Client Secret above and save settings to enable authorization.', 'auto-download-access') . '</p>';
        }
        ?>

        <hr>
        <h2><?php _e('Troubleshooting', 'auto-download-access'); ?></h2>
        <form method="post">
             <?php wp_nonce_field('ada_reset_action', 'ada_reset_nonce'); ?>
             <p><?php _e('If you are having issues with authorization, you can reset all settings and tokens.', 'auto-download-access'); ?></p>
             <button type="submit" class="button button-secondary" onclick="return confirm('<?php _e('Are you sure you want to delete all settings and authorization tokens?', 'auto-download-access'); ?>');"><?php _e('Reset and Clear Settings', 'auto-download-access'); ?></button>
        </form>
        <div class="notice notice-warning" style="margin-top: 20px;">
            <p><strong><?php _e('Caching Notice:', 'auto-download-access'); ?></strong> <?php _e('Aggressive server-side or plugin caching (especially object caching) can interfere with the authorization process. If you experience issues, please ensure that your admin pages (specifically URLs containing <code>/wp-admin/</code>) are excluded from caching.', 'auto-download-access'); ?></p>
        </div>
    </div>
    <?php
}
