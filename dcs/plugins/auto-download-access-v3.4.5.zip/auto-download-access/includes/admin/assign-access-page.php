
<?php
if (!defined('ABSPATH')) exit;

function ada_render_assign_access_page() {
    if (isset($_POST['assign_access_nonce']) && wp_verify_nonce($_POST['assign_access_nonce'], 'assign_access_action')) {
        $order_ids = isset($_POST['order_ids']) ? array_map('intval', $_POST['order_ids']) : [];
        if (!empty($order_ids)) {
            $client = ada_get_google_client();
            if ($client->getAccessToken()) {
                $service = new Google_Service_Drive($client);
                $processed_count = 0;
                $error_messages = [];
                foreach ($order_ids as $order_id) {
                    $order = wc_get_order($order_id);
                    if (!$order) continue;

                    $skus = [];
                    foreach ($order->get_items() as $item) {
                        $product = $item->get_product();
                        if ($product && $product->is_virtual()) {
                            $sku = $product->get_sku();
                            if (!empty($sku)) {
                                $skus[] = $sku;
                            }
                        }
                    }

                    if (!empty($skus)) {
                        $found_files = ada_find_files_in_drive($service, array_unique($skus));
                        $download_links = [];
                        $files_data_for_db = [];

                        foreach ($found_files as $sku => $file) {
                            if ($file) {
                                try {
                                    $permission = new Google_Service_Drive_Permission([
                                        'type' => 'anyone',
                                        'role' => 'reader'
                                    ]);
                                    $service->permissions->create($file->getId(), $permission);
                                    $download_links[$sku] = $file->getWebContentLink();
                                    $files_data_for_db[] = ['sku' => $sku, 'name' => $file->getName(), 'id' => $file->getId()];
                                } catch (Exception $e) {
                                    $error_messages[] = sprintf(__('Could not set permissions for file %s. Error: %s', 'auto-download-access'), $file->getName(), $e->getMessage());
                                }
                            }
                        }

                        if (!empty($download_links)) {
                            $email_sent = ada_send_download_links_email($order_id, $download_links);
                            if ($email_sent) {
                                update_post_meta($order_id, '_ada_access_granted', 'yes');
                                update_post_meta($order_id, '_ada_access_granted_date', current_time('mysql'));

                                global $wpdb;
                                $table_name = $wpdb->prefix . 'ada_access_history';
                                $wpdb->insert($table_name, [
                                    'order_id' => $order_id,
                                    'customer_email' => $order->get_billing_email(),
                                    'grant_date' => current_time('mysql'),
                                    'granted_by' => get_current_user_id(),
                                    'files_data' => wp_json_encode($files_data_for_db)
                                ]);

                                $processed_count++;
                            } else {
                                $error_messages[] = sprintf(__('Email could not be sent for order #%s.', 'auto-download-access'), $order->get_order_number());
                            }
                        }
                    }
                }
                if (!empty($error_messages)) {
                    foreach($error_messages as $msg) {
                        echo '<div class="notice notice-error is-dismissible"><p>' . esc_html($msg) . '</p></div>';
                    }
                }
                if ($processed_count > 0) {
                    echo '<div class="notice notice-success is-dismissible"><p>' . sprintf(__('Access assigned for %d order(s).', 'auto-download-access'), $processed_count) . '</p></div>';
                } elseif (empty($error_messages)) {
                     echo '<div class="notice notice-warning is-dismissible"><p>' . __('Could not find any images or send emails for the selected orders.', 'auto-download-access') . '</p></div>';
                }
            } else {
                echo '<div class="notice notice-error"><p>' . __('Google Drive is not authorized. Please go to settings to authorize.', 'auto-download-access') . '</p></div>';
            }
        }
    }

    $orders = ada_get_orders_for_access();
    $client = ada_get_google_client();
    $is_authorized = $client->getAccessToken() && !$client->isAccessTokenExpired();
    $service = $is_authorized ? new Google_Service_Drive($client) : null;
    ?>
    <div class="wrap ada-wrap">
        <h1><?php _e('ADA - Assign Access', 'auto-download-access'); ?></h1>

        <form method="post">
            <?php wp_nonce_field('assign_access_action', 'assign_access_nonce'); ?>
            <p>
                <button type="submit" class="button button-primary" <?php echo empty($orders) || !$is_authorized ? 'disabled' : ''; ?>>
                    <?php _e('Assign Access & Send Email', 'auto-download-access'); ?>
                </button>
            </p>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <td id="cb" class="manage-column column-cb check-column"><input type="checkbox" /></td>
                        <th scope="col" class="manage-column"><?php _e('Order', 'auto-download-access'); ?></th>
                        <th scope="col" class="manage-column"><?php _e('Customer', 'auto-download-access'); ?></th>
                        <th scope="col" class="manage-column"><?php _e('Status', 'auto-download-access'); ?></th>
                        <th scope="col" class="manage-column"><?php _e('Items / Detected Images', 'auto-download-access'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($orders)) : ?>
                        <?php foreach ($orders as $order) : 
                            $skus = [];
                            $item_names = [];
                            foreach ($order->get_items() as $item) {
                                $product = $item->get_product();
                                if ($product && $product->is_virtual()) {
                                    $sku = $product->get_sku();
                                    if (!empty($sku)) {
                                        $skus[] = $sku;
                                    }
                                    $item_names[] = $item->get_name();
                                }
                            }
                            $unique_skus = array_unique($skus);
                            $found_files = $service ? ada_find_files_in_drive($service, $unique_skus) : array_fill_keys($unique_skus, null);
                            $found_count = count(array_filter($found_files));
                        ?>
                        <tr>
                            <th scope="row" class="check-column"><input type="checkbox" name="order_ids[]" value="<?php echo $order->get_id(); ?>" /></th>
                            <td><a href="<?php echo get_edit_post_link($order->get_id()); ?>">#<?php echo $order->get_order_number(); ?></a></td>
                            <td><?php echo $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(); ?></td>
                            <td><span class="order-status status-<?php echo $order->get_status(); ?>"><span><?php echo wc_get_order_status_name($order->get_status()); ?></span></span></td>
                            <td>
                                <?php echo implode(', ', $item_names); ?><br>
                                <small>
                                    <?php 
                                    $status_color = ($found_count == count($unique_skus) && $found_count > 0) ? 'green' : 'red';
                                    echo '<strong>' . __('Detected:', 'auto-download-access') . '</strong> ';
                                    echo '<span style="color:' . $status_color . ';">' . $found_count . ' / ' . count($unique_skus) . '</span>';
                                    ?>
                                </small>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="5"><?php _e('No orders requiring access assignment found.', 'auto-download-access'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </form>
    </div>
    <?php
}
