
<?php
if (!defined('ABSPATH')) exit;

require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';

class ADA_History_List_Table extends WP_List_Table {

    public function __construct() {
        parent::__construct([
            'singular' => __('Access Record', 'auto-download-access'),
            'plural'   => __('Access Records', 'auto-download-access'),
            'ajax'     => false
        ]);
    }

    public function get_columns() {
        return [
            'order_id'       => __('Order', 'auto-download-access'),
            'customer_email' => __('Customer', 'auto-download-access'),
            'grant_date'     => __('Date Granted', 'auto-download-access'),
            'granted_by'     => __('Granted By', 'auto-download-access'),
            'files_data'     => __('Files', 'auto-download-access'),
            'actions'        => __('Actions', 'auto-download-access'),
        ];
    }

    public function prepare_items() {
        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = [$columns, $hidden, $sortable];

        $per_page = $this->get_items_per_page('records_per_page', 20);
        $current_page = $this->get_pagenum();
        $total_items = ada_get_history_count();

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page
        ]);

        $args = [
            'per_page' => $per_page,
            'current_page' => $current_page,
            'orderby' => isset($_GET['orderby']) ? sanitize_key($_GET['orderby']) : 'grant_date',
            'order' => isset($_GET['order']) ? strtoupper(sanitize_key($_GET['order'])) : 'DESC',
        ];

        $this->items = ada_get_access_history($args);
    }

    protected function get_sortable_columns() {
        return [
            'order_id'   => ['order_id', false],
            'grant_date' => ['grant_date', true],
        ];
    }

    public function column_default($item, $column_name) {
        switch ($column_name) {
            case 'order_id':
                $order = wc_get_order($item->order_id);
                return $order ? '<a href="' . get_edit_post_link($item->order_id) . '">#' . $order->get_order_number() . '</a>' : '#' . $item->order_id;
            case 'customer_email':
                return esc_html($item->customer_email);
            case 'grant_date':
                return date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($item->grant_date));
            case 'granted_by':
                $user = get_userdata($item->granted_by);
                return $user ? esc_html($user->display_name) : __('Unknown', 'auto-download-access');
            case 'files_data':
                $files = json_decode($item->files_data);
                if (is_array($files)) {
                    return count($files) . ' ' . _n('file', 'files', count($files), 'auto-download-access');
                }
                return __('N/A', 'auto-download-access');
            default:
                return print_r($item, true);
        }
    }

    public function column_actions($item) {
        $resend_url = wp_nonce_url(admin_url('admin.php?page=ada-access-history&action=resend&record_id=' . $item->id), 'ada_resend_email_' . $item->id);
        return sprintf('<a href="%s" class="button button-secondary">%s</a>', esc_url($resend_url), __('Resend Email', 'auto-download-access'));
    }
}

function ada_handle_history_actions() {
    if (isset($_GET['action']) && $_GET['action'] === 'resend' && isset($_GET['record_id'])) {
        $record_id = intval($_GET['record_id']);
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'ada_resend_email_' . $record_id)) {
            wp_die(__('Security check failed', 'auto-download-access'));
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'ada_access_history';
        $record = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $record_id));

        if ($record) {
            $files = json_decode($record->files_data, true);
            $download_links = [];

            $client = ada_get_google_client();
            if ($client->getAccessToken()) {
                $service = new Google_Service_Drive($client);
                foreach($files as $file) {
                    try {
                        $gdrive_file = $service->files->get($file['id'], ['fields' => 'webContentLink']);
                        $download_links[$file['sku']] = $gdrive_file->getWebContentLink();
                    } catch (Exception $e) {
                        // File might not exist anymore, skip it
                    }
                }
            }

            if (!empty($download_links)) {
                $sent = ada_send_download_links_email($record->order_id, $download_links);
                if ($sent) {
                    add_action('admin_notices', function() {
                        echo '<div class="notice notice-success is-dismissible"><p>' . __('Email resent successfully.', 'auto-download-access') . '</p></div>';
                    });
                } else {
                    add_action('admin_notices', function() {
                        echo '<div class="notice notice-error is-dismissible"><p>' . __('Failed to resend email.', 'auto-download-access') . '</p></div>';
                    });
                }
            } else {
                 add_action('admin_notices', function() {
                    echo '<div class="notice notice-error is-dismissible"><p>' . __('Could not retrieve download links. Files may have been removed from Google Drive.', 'auto-download-access') . '</p></div>';
                });
            }
        }
    }
}

function ada_render_history_page() {
    ada_handle_history_actions();
    $list_table = new ADA_History_List_Table();
    $list_table->prepare_items();
    ?>
    <div class="wrap ada-wrap">
        <h1><?php _e('ADA - Access History', 'auto-download-access'); ?></h1>
        <form method="get">
            <input type="hidden" name="page" value="<?php echo esc_attr($_REQUEST['page']); ?>" />
            <?php $list_table->display(); ?>
        </form>
    </div>
    <?php
}
