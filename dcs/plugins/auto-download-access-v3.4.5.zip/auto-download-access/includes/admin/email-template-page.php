
<?php
if (!defined('ABSPATH')) exit;

function ada_render_email_template_page() {
    if (isset($_GET['status']) && $_GET['status'] == 'success') {
        echo '<div class="notice notice-success is-dismissible"><p>' . __('Email template saved successfully.', 'auto-download-access') . '</p></div>';
    }

    $subject = get_option('ada_email_subject', __('Your photos from order #{order_number} are ready!', 'auto-download-access'));
    $body = get_option('ada_email_body', file_get_contents(ADA_PLUGIN_DIR . 'templates/default-email.html'));
    ?>
    <div class="wrap ada-wrap">
        <h1><?php _e('ADA - Email Template', 'auto-download-access'); ?></h1>
        <p><?php _e('Customize the email that will be sent to your customers with the download links.', 'auto-download-access'); ?></p>

        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <input type="hidden" name="action" value="ada_save_email_template">
            <?php wp_nonce_field('ada_save_email_template', 'ada_email_template_nonce'); ?>

            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row">
                            <label for="ada_email_subject"><?php _e('Email Subject', 'auto-download-access'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="ada_email_subject" name="ada_email_subject" value="<?php echo esc_attr($subject); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ada_email_body"><?php _e('Email Body', 'auto-download-access'); ?></label>
                        </th>
                        <td>
                            <?php
                            wp_editor($body, 'ada_email_body', [
                                'textarea_name' => 'ada_email_body',
                                'media_buttons' => false,
                                'textarea_rows' => 15,
                            ]);
                            ?>
                        </td>
                    </tr>
                </tbody>
            </table>

            <div class="ada-placeholders">
                <h3><?php _e('Available Placeholders', 'auto-download-access'); ?></h3>
                <p><code>{customer_name}</code> - <?php _e("The customer's first name.", 'auto-download-access'); ?></p>
                <p><code>{order_number}</code> - <?php _e('The WooCommerce order number.', 'auto-download-access'); ?></p>
                <p><code>{download_links}</code> - <?php _e('A list of download links for the purchased images.', 'auto-download-access'); ?></p>
                <p><code>{site_title}</code> - <?php _e('Your website title.', 'auto-download-access'); ?></p>
            </div>

            <?php submit_button(__('Save Template', 'auto-download-access')); ?>
        </form>
    </div>
    <?php
}
