
<?php
if (!defined('ABSPATH')) exit;

function ada_ajax_browse_gdrive() {
    $folder_id = isset($_POST['folder_id']) ? sanitize_text_field($_POST['folder_id']) : 'root';

    $client = ada_get_google_client();
    if (!$client->getAccessToken()) {
        wp_send_json_error(['message' => 'Not authorized']);
    }
    $service = new Google_Service_Drive($client);

    try {
        $path = [];
        if ($folder_id !== 'root') {
            $current_folder_id = $folder_id;
            while (true) {
                $folder = $service->files->get($current_folder_id, ['fields' => 'id, name, parents']);
                array_unshift($path, ['id' => $folder->getId(), 'name' => $folder->getName()]);
                $parents = $folder->getParents();
                if (empty($parents)) {
                    break;
                }
                $current_folder_id = $parents[0];
            }
        }

        $query = "'" . esc_sql($folder_id) . "' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false";
        $results = $service->files->listFiles([
            'q' => $query,
            'pageSize' => 100,
            'fields' => 'files(id, name)',
            'orderBy' => 'name'
        ]);

        $folders = [];
        foreach ($results->getFiles() as $file) {
            $folders[] = ['id' => $file->getId(), 'name' => $file->getName()];
        }

        ob_start();
        ?>
        <div class="ada-browser-path">
            <strong><?php _e('Current Path:', 'auto-download-access'); ?></strong> 
            <a href="#" class="ada-folder-link" data-folder-id="root">My Drive</a> /
            <?php foreach ($path as $part): ?>
                <a href="#" class="ada-folder-link" data-folder-id="<?php echo esc_attr($part['id']); ?>"><?php echo esc_html($part['name']); ?></a> /
            <?php endforeach; ?>
            <input type="hidden" id="ada-current-folder-id" value="<?php echo esc_attr($folder_id); ?>">
        </div>
        <ul class="ada-folder-list">
            <?php if ($folder_id !== 'root'): 
                $parent_folder = $service->files->get($folder_id, ['fields' => 'parents']);
                $parent_id = !empty($parent_folder->getParents()) ? $parent_folder->getParents()[0] : 'root';
            ?>
                <li><a href="#" class="ada-folder-link" data-folder-id="<?php echo esc_attr($parent_id); ?>">.. (<?php _e('Up', 'auto-download-access'); ?>)</a></li>
            <?php endif; ?>

            <?php if (empty($folders)): ?>
                <li><?php _e('No subfolders found.', 'auto-download-access'); ?></li>
            <?php else: ?>
                <?php foreach ($folders as $folder): ?>
                    <li><a href="#" class="ada-folder-link" data-folder-id="<?php echo esc_attr($folder['id']); ?>"><?php echo esc_html($folder['name']); ?></a></li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ul>
        <?php
        $html = ob_get_clean();

        wp_send_json_success(['html' => $html]);

    } catch (Exception $e) {
        wp_send_json_error(['message' => $e->getMessage()]);
    }
}
