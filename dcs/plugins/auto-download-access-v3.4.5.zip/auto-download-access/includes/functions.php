
<?php
if (!defined('ABSPATH')) exit;

function ada_get_orders_for_access() {
    $args = [
        'status' => ['wc-processing', 'wc-completed'],
        'limit' => -1,
        'meta_query' => [
            [
                'key' => '_ada_access_granted',
                'compare' => 'NOT EXISTS'
            ]
        ]
    ];
    $orders = wc_get_orders($args);
    $filtered_orders = [];

    foreach ($orders as $order) {
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if ($product && $product->is_virtual()) {
                $filtered_orders[] = $order;
                break;
            }
        }
    }
    return $filtered_orders;
}

function ada_get_google_client() {
    require_once ADA_PLUGIN_DIR . 'vendor/autoload.php';

    $client = new Google_Client();
    $client->setApplicationName('Auto Download Access');
    $client->setScopes(Google_Service_Drive::DRIVE); // Changed to DRIVE for permissions
    $client->setAccessType('offline');
    $client->setPrompt('select_account consent');

    $credentials = get_option('ada_google_credentials');
    if (!empty($credentials['client_id']) && !empty($credentials['client_secret'])) {
        $client->setClientId($credentials['client_id']);
        $client->setClientSecret($credentials['client_secret']);
        $client->setRedirectUri(admin_url('admin-ajax.php?action=ada_google_auth'));
    }

    $token = get_option('ada_google_token');
    if ($token) {
        $client->setAccessToken($token);
    }

    if ($client->isAccessTokenExpired()) {
        $refresh_token = get_option('ada_google_refresh_token_single');
        if ($refresh_token) {
            $client->fetchAccessTokenWithRefreshToken($refresh_token);
            $new_token = $client->getAccessToken();
            if ($new_token) {
                update_option('ada_google_token', $new_token);
                if (isset($new_token['refresh_token'])) {
                     update_option('ada_google_refresh_token_single', $new_token['refresh_token']);
                }
            }
        }
    }

    return $client;
}

function ada_find_files_in_drive($service, $skus) {
    $found_files = [];
    $options = get_option('ada_settings');
    $main_folder_id = isset($options['gdrive_folder_id']) && !empty($options['gdrive_folder_id']) ? trim($options['gdrive_folder_id']) : 'root';

    foreach ($skus as $sku) {
        if (empty($sku)) continue;

        $query = "name = '" . esc_sql($sku) . ".jpg' and '" . esc_sql($main_folder_id) . "' in parents and trashed = false";
        try {
            $results = $service->files->listFiles([
                'q' => $query,
                'pageSize' => 1,
                'fields' => 'files(id, name, webViewLink, webContentLink)'
            ]);

            if (count($results->getFiles()) > 0) {
                $found_files[$sku] = $results->getFiles()[0];
            } else {
                $found_files[$sku] = null;
            }
        } catch (Exception $e) {
            // Log error if needed
            $found_files[$sku] = null;
        }
    }
    return $found_files;
}

function ada_send_download_links_email($order_id, $download_links) {
    $order = wc_get_order($order_id);
    if (!$order) return false;

    $customer_email = $order->get_billing_email();
    if (!$customer_email) return false;

    $subject_template = get_option('ada_email_subject', __('Your photos from order #{order_number} are ready!', 'auto-download-access'));
    $body_template = get_option('ada_email_body', file_get_contents(ADA_PLUGIN_DIR . 'templates/default-email.html'));

    $links_html = '<ul>';
    foreach ($download_links as $sku => $link) {
        $links_html .= '<li>' . esc_html($sku) . ': <a href="' . esc_url($link) . '">' . __('Download', 'auto-download-access') . '</a></li>';
    }
    $links_html .= '</ul>';

    $replacements = [
        '{customer_name}' => $order->get_billing_first_name(),
        '{order_number}' => $order->get_order_number(),
        '{download_links}' => $links_html,
        '{site_title}' => get_bloginfo('name'),
    ];

    $subject = str_replace(array_keys($replacements), array_values($replacements), $subject_template);
    $body = str_replace(array_keys($replacements), array_values($replacements), $body_template);

    $headers = ['Content-Type: text/html; charset=UTF-8'];

    // Also send a copy to the admin
    $admin_email = get_option('admin_email');
    $headers[] = 'Bcc: ' . $admin_email;

    return wp_mail($customer_email, $subject, $body, $headers);
}

function ada_get_access_history($args = []) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ada_access_history';

    $defaults = [
        'per_page' => 20,
        'current_page' => 1,
        'orderby' => 'grant_date',
        'order' => 'DESC',
    ];
    $args = wp_parse_args($args, $defaults);

    $offset = ($args['current_page'] - 1) * $args['per_page'];

    $sql = "SELECT * FROM {$table_name} ORDER BY {$args['orderby']} {$args['order']} LIMIT %d OFFSET %d";
    $results = $wpdb->get_results($wpdb->prepare($sql, $args['per_page'], $offset));

    return $results;
}

function ada_get_history_count() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ada_access_history';
    return (int) $wpdb->get_var("SELECT COUNT(id) FROM {$table_name}");
}

// Activation hook to create database table
function ada_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ada_access_history';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        order_id bigint(20) NOT NULL,
        customer_email varchar(255) NOT NULL,
        grant_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        granted_by bigint(20) NOT NULL,
        files_data longtext NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(ADA_PLUGIN_DIR . 'auto-download-access.php', 'ada_activate');
