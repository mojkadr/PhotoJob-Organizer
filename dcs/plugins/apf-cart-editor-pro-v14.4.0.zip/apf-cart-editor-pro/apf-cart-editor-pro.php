<?php
/**
 * Plugin Name: APF Cart Editor PRO
 * Plugin URI: https://github.com/mojkadr/Cart-editor
 * Description: Zaawansowana edycja koszyka WooCommerce z integracją Advanced Product Fields
 * Version: 14.4.0
 * Author: Claude AI
 * Author URI: https://github.com/mojkadr/Cart-editor
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 8.0
 * WC tested up to: 8.5
 * Text Domain: apf-cart-editor-pro
 * Domain Path: /languages
 */

defined('ABSPATH') || exit;

if (!class_exists('APF_Cart')) {

    class APF_Cart {

        private static $instance = null;
        private $extra_print_price = 10.00;  // Cena dodatkowej odbitki
        private $extra_folio_price = 30.00;  // Cena dodatkowej karty Folio BOX
        private $extra_packaging_price = 30.00;  // Cena dodatkowego opakowania
        private $debug = true; // DEBUG MODE

        public static function get_instance() {
            if (null === self::$instance) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private function __construct() {
            // AJAX endpoints
            add_action('wp_ajax_apf_get_v14', [$this, 'ajax_get']);
            add_action('wp_ajax_nopriv_apf_get_v14', [$this, 'ajax_get']);

            add_action('wp_ajax_apf_set_v14', [$this, 'ajax_set']);
            add_action('wp_ajax_nopriv_apf_set_v14', [$this, 'ajax_set']);

            // Usuwanie pojedynczej opcji
            add_action('wp_ajax_apf_remove_option_v14', [$this, 'ajax_remove_option']);
            add_action('wp_ajax_nopriv_apf_remove_option_v14', [$this, 'ajax_remove_option']);

            // NOWE: Usuwanie całego produktu z koszyka
            add_action('wp_ajax_apf_remove_product_v14', [$this, 'ajax_remove_product']);
            add_action('wp_ajax_nopriv_apf_remove_product_v14', [$this, 'ajax_remove_product']);

            add_action('woocommerce_before_calculate_totals', [$this, 'calc'], 9999);
            add_action('woocommerce_after_calculate_totals', [$this, 'restore_qty'], 99999);
            add_action('wp', [$this, 'force_calc_on_cart']);
            add_action('wp_footer', [$this, 'assets']);
            add_filter('rest_authentication_errors', [$this, 'rest_fix'], 999);
        }

        private function log($message) {
            if ($this->debug) {
                error_log('[APF v14.1 DEBUG] ' . $message);
            }
        }

        public function force_calc_on_cart() {
            if (is_cart() && WC()->cart) {
                add_action('woocommerce_before_calculate_totals', [$this, 'calc'], 9999);
            }
        }

        public function rest_fix($result) {
            if (is_user_logged_in()) return $result;
            if (is_wp_error($result)) return $result;

            $uri = $_SERVER['REQUEST_URI'] ?? '';
            $allowed_paths = [
                '/wp-json/wc/store/',
                '/wp-json/wc/store/v1/',
                '/wp-json/wc/store/batch',
                '/wp-json/wc/store/cart',
                '/wp-json/wc/store/checkout',
            ];

            foreach ($allowed_paths as $path) {
                if (strpos($uri, $path) !== false) {
                    return null;
                }
            }

            return $result;
        }

        /**
         * Pobiera dane z koszyka z PEŁNYM DEBUGOWANIEM
         */
        public function ajax_get() {
            check_ajax_referer('apf14', 'n');

            if (!WC()->cart) {
                wp_send_json_error(['m' => 'Brak koszyka']);
            }

            $this->log('=== AJAX GET START ===');
            $items = [];

            foreach (WC()->cart->get_cart() as $key => $item) {
                $this->log("Produkt: {$item['data']->get_name()}, key=$key");

                if (isset($item['wapf'])) {
                    $this->log("Znaleziono dane WAPF, pól: " . count($item['wapf']));
                    $wapf_data = [];

                    foreach ($item['wapf'] as $fi => $field) {
                        $this->log("  Pole $fi:");
                        $this->log("    label: " . ($field['label'] ?? 'brak'));
                        // POPRAWKA v14.2.3: Jeśli raw jest tablicą, użyj json_encode
                        $raw_value = $field['raw'] ?? 'brak';
                        if (is_array($raw_value)) {
                            $this->log("    raw: " . json_encode($raw_value, JSON_UNESCAPED_UNICODE));
                        } else {
                            $this->log("    raw: " . $raw_value);
                        }
                        $this->log("    type: " . ($field['type'] ?? 'brak'));

                        if (isset($field['values'])) {
                            $this->log("    Wartości: " . count($field['values']));

                            foreach ($field['values'] as $vi => $value) {
                                $this->log("      Value $vi:");
                                $this->log("        label: " . ($value['label'] ?? 'brak'));
                                $this->log("        price: " . ($value['price'] ?? 0));
                                $this->log("        qty: " . ($value['qty'] ?? 'brak'));
                                $this->log("        _apf_qty: " . ($value['_apf_qty'] ?? 'brak'));
                                $this->log("        calc_price: " . ($value['calc_price'] ?? 'brak'));

                                // Dump całego value dla analizy
                                $this->log("        RAW VALUE: " . json_encode($value, JSON_UNESCAPED_UNICODE));

                                // DEBUG SZCZEGÓŁOWY: Pokaż wszystkie klucze qty
                                $this->log("        PRE get_qty(): _apf_qty=" . ($value['_apf_qty'] ?? 'BRAK') . ", qty=" . ($value['qty'] ?? 'BRAK') . ", quantity[qty]=" . ($value['quantity']['qty'] ?? 'BRAK'));

                                // POPRAWKA: Najpierw field label (pełna nazwa), potem value label (wartość)
                                // APF przechowuje:
                                // - field['label'] = "Wydruk odbitki: 15x23cm" (pełna nazwa)
                                // - value['label'] = "15x23cm" (tylko wartość)
                                $field_label = $field['label'] ?? '';
                                $value_label = $value['label'] ?? '';

                                // Użyj field label jako głównego (jeśli istnieje)
                                if (!empty($field_label)) {
                                    $label = $field_label;
                                } elseif (!empty($value_label)) {
                                    $label = $value_label;
                                } else {
                                    $label = '';
                                }

                                $price = floatval($value['price'] ?? 0);

                                // Pomiń puste
                                if (empty($label) && $price <= 0) {
                                    $this->log("        -> POMIJAM (puste)");
                                    continue;
                                }

                                $qty = $this->get_qty($value, $label);
                                $type = $this->get_field_type($label, $value);

                                $this->log("        -> DODAJĘ: type=$type, qty=$qty");

                                $wapf_data[] = [
                                    'fi' => $fi,
                                    'vi' => $vi,
                                    'label' => $label,
                                    'price' => $price,
                                    'qty' => $qty,
                                    'type' => $type
                                ];
                            }
                        }
                    }

                    if (!empty($wapf_data)) {
                        $items[] = [
                            'key' => $key,
                            'wapf' => $wapf_data,
                            'product_name' => $item['data']->get_name()
                        ];
                    }
                }
            }

            $this->log('=== AJAX GET END, zwracam ' . count($items) . ' produktów ===');
            wp_send_json_success($items);
        }

        /**
         * POPRAWIONA v3: Określa typ pola z obsługą Folio, odbitek i opakowań
         */
        private function get_field_type($label, $value_data = null) {
            $this->log("    get_field_type('$label')");

            $label_lower = mb_strtolower($label);

            // Wersja elektroniczna
            if (stripos($label, 'Wersja elektroniczna') !== false ||
                stripos($label, 'JPG') !== false ||
                stripos($label, 'jpeg') !== false) {
                $this->log("      -> electronic");
                return 'electronic';
            }

            // DODATKOWE karty Folio BOX (sprawdzaj PRZED opakowaniami - bardziej specyficzne!)
            if ((stripos($label, 'dodatkow') !== false || stripos($label, 'Ilość dodatkowych') !== false) &&
                stripos($label, 'Folio') !== false) {

                if (stripos($label, 'Standard') !== false) {
                    $this->log("      -> extra_folio_standard");
                    return 'extra_folio_standard';
                }
                if (stripos($label, 'Czarna ramka') !== false || stripos($label, 'Czarna') !== false) {
                    $this->log("      -> extra_folio_black");
                    return 'extra_folio_black';
                }

                $this->log("      -> extra_folio");
                return 'extra_folio';
            }

            // DODATKOWE opakowania (sprawdzaj PO Folio - mniej specyficzne)
            if ((stripos($label, 'dodatkow') !== false || stripos($label, 'Ilość dodatkowych') !== false) &&
                (stripos($label, 'opakowa') !== false || stripos($label, 'BOX') !== false)) {
                $this->log("      -> extra_packaging");
                return 'extra_packaging';
            }

            // GŁÓWNE opakowania BOX
            if (stripos($label, 'Opakowanie BOX') !== false ||
                (stripos($label, 'DODATKI') !== false && stripos($label, 'Opakowanie') !== false)) {
                $this->log("      -> packaging");
                return 'packaging';
            }

            // GŁÓWNE karty Folio BOX
            if (stripos($label, 'Folio') !== false) {
                // Sprawdź wartość (value label) jeśli dostępna
                $value_label = $value_data['label'] ?? '';

                if (stripos($label, 'Standard') !== false || stripos($value_label, 'Standard') !== false) {
                    $this->log("      -> folio_standard");
                    return 'folio_standard';
                }
                if (stripos($label, 'Czarna ramka') !== false || stripos($value_label, 'Czarna ramka') !== false ||
                    stripos($label, 'Czarna') !== false || stripos($value_label, 'Czarna') !== false) {
                    $this->log("      -> folio_black");
                    return 'folio_black';
                }

                $this->log("      -> folio");
                return 'folio';
            }

            // GŁÓWNE odbitki - wykrywanie formatu
            if (stripos($label, 'Wydruk odbitki') !== false) {
                // Sprawdź czy w labelu jest wymiar
                if (preg_match('/15\s*x\s*23|15x23/i', $label)) {
                    $this->log("      -> print_15x23");
                    return 'print_15x23';
                }
                if (preg_match('/20\s*x\s*30|20x30/i', $label)) {
                    $this->log("      -> print_20x30");
                    return 'print_20x30';
                }

                // Sprawdź wartość (value label) jeśli dostępna
                $value_label = $value_data['label'] ?? '';
                if (preg_match('/15\s*x\s*23|15x23/i', $value_label)) {
                    $this->log("      -> print_15x23 (z value)");
                    return 'print_15x23';
                }
                if (preg_match('/20\s*x\s*30|20x30/i', $value_label)) {
                    $this->log("      -> print_20x30 (z value)");
                    return 'print_20x30';
                }

                // Fallback: wykryj po cenie jeśli dostępna
                $price = floatval($value_data['price'] ?? 0);
                if ($price > 0) {
                    // 15x23 zazwyczaj kosztuje 60-80 zł, 20x30 kosztuje 90-120 zł
                    if ($price < 85) {
                        $this->log("      -> print_15x23 (po cenie: $price zł)");
                        return 'print_15x23';
                    } else {
                        $this->log("      -> print_20x30 (po cenie: $price zł)");
                        return 'print_20x30';
                    }
                }

                // Jeśli nie udało się wykryć, zwróć generyczny typ
                $this->log("      -> print (bez wymiaru)");
                return 'print';
            }

            // DODATKOWE odbitki
            if ((stripos($label, 'dodatkow') !== false && stripos($label, 'odbitek') !== false) ||
                stripos($label, 'Ilość dodatkowych odbitek') !== false) {

                if (preg_match('/15\s*x\s*23|15x23/i', $label)) {
                    $this->log("      -> extra_15x23");
                    return 'extra_15x23';
                }
                if (preg_match('/20\s*x\s*30|20x30/i', $label)) {
                    $this->log("      -> extra_20x30");
                    return 'extra_20x30';
                }
            }

            $this->log("      -> standard");
            return 'standard';
        }

        /**
         * NOWA v14.2.5: Usuwa prefiks i przyrostek ilości z labelu
         * Przykłady:
         *   "2x Label" → "Label"
         *   "Label (2)" → "Label"
         *   "Ilość dodatkowych odbitek 15x23cm: 2" → "Ilość dodatkowych odbitek 15x23cm"
         */
        private function strip_qty_from_label($label) {
            // POPRAWKA v14.3.1: Usuń przedrostek "2x" lub "2x " lub "2 x " (nawet bez spacji po 'x')
            $label = preg_replace('/^(\d+)\s*x\s*/i', '', $label);
            // Usuń przyrostek " (2)"
            $label = preg_replace('/\s*\((\d+)\)$/i', '', $label);
            // POPRAWKA v14.2.6: Usuń przyrostek ": 2" (APF dodaje ilość na końcu niektórych labeli)
            $label = preg_replace('/:\s*(\d+)$/i', '', $label);
            return trim($label);
        }

        /**
         * POPRAWIONA v14.2.7: Dodaje prefiks ilości do labelu
         * - Jeśli label to TYLKO LICZBA (np. "1", "2") → zwróć nową liczbę qty (np. "3")
         * - Jeśli label to TEKST (np. "15x23cm") → dodaj prefiks (np. "3x 15x23cm")
         */
        private function format_label_with_qty($label, $qty) {
            // Najpierw usuń ewentualny istniejący prefiks/przyrostek ilości
            $clean_label = $this->strip_qty_from_label($label);

            // KLUCZ v14.2.7: Sprawdź czy clean_label to TYLKO LICZBA
            // APF dla pól typu "number" używa samej liczby jako labelu (np. "1", "2", "15")
            // W takim przypadku field['label'] zawiera pełną nazwę (np. "Ilość dodatkowych odbitek")
            // a value['label'] to tylko liczba
            if (preg_match('/^\d+$/', $clean_label)) {
                // To TYLKO LICZBA - zamień na nową ilość (bez prefiksu "3x")
                return (string)$qty;
            }

            // To TEKST (np. "15x23cm", "Standard", "Czarna ramka")
            // Dodaj prefiks ilości jeśli qty > 1
            if ($qty > 1) {
                return $qty . 'x ' . $clean_label;
            }

            // Jeśli qty = 1 lub 0, zwróć czysty label
            return $clean_label;
        }

        /**
         * POPRAWIONA: Pobiera ilość z synchronizacją APF
         */
        private function get_qty($value, $label = '') {
            $this->log("      get_qty():");

            // 1. PRIORYTET: Ręcznie ustawiona ilość przez użytkownika
            if (isset($value['_apf_qty'])) {
                $qty = max(0, intval($value['_apf_qty']));
                $this->log("        z _apf_qty = $qty");
                return $qty;
            }

            // 2. SYNCHRONIZACJA APF: Pole qty bezpośrednio z APF
            if (isset($value['qty']) && $value['qty'] > 0) {
                $qty = intval($value['qty']);
                $this->log("        z APF qty = $qty");
                return $qty;
            }

            // 3. Oblicz z calc_price / price
            $price = floatval($value['price'] ?? 0);
            $calc = floatval($value['calc_price'] ?? 0);

            if ($price > 0 && $calc > 0) {
                $q = (int)round($calc / $price);
                if ($q > 0) {
                    $this->log("        z calc_price/price = $q");
                    return $q;
                }
            }

            // 4. Szukaj w labelu (np. "2x Nazwa" lub "Nazwa (2)")
            if (!empty($label)) {
                if (preg_match('/^(\d+)x\s+/i', $label, $m)) {
                    $qty = intval($m[1]);
                    $this->log("        z labelu (przedrostek) = $qty");
                    return $qty;
                }
                if (preg_match('/\((\d+)\)$/i', $label, $m)) {
                    $qty = intval($m[1]);
                    $this->log("        z labelu (przyrostek) = $qty");
                    return $qty;
                }
            }

            // 5. Domyślnie: jeśli price > 0, to qty = 1
            if ($price > 0) {
                $this->log("        domyślnie (price>0) = 1");
                return 1;
            }

            // 6. Jeśli calc > 0 a price = 0
            if ($calc > 0) {
                $this->log("        z calc (price=0) = 1");
                return 1;
            }

            $this->log("        brak danych = 0");
            return 0;
        }

        /**
         * POPRAWIONA v3: Ustawia ilość + WYMUSZA pełne przeliczenie APF
         */
        public function ajax_set() {
            check_ajax_referer('apf14', 'n');

            $k = sanitize_text_field($_POST['k'] ?? '');
            $f = intval($_POST['f'] ?? 0);
            $v = intval($_POST['v'] ?? 0);
            $q = max(0, intval($_POST['q'] ?? 0));
            $type = sanitize_text_field($_POST['type'] ?? '');

            $this->log("AJAX SET: key=$k, field=$f, value=$v, qty=$q, type=$type");

            if (!WC()->cart || !isset(WC()->cart->cart_contents[$k])) {
                wp_send_json_error(['m' => 'Produkt nie znaleziony']);
            }

            if (!isset(WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v])) {
                wp_send_json_error(['m' => 'Opcja nie znaleziona']);
            }

            // Pobierz cenę jednostkową
            $price = floatval(WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['price'] ?? 0);

            // POPRAWKA v14.3.0: Ustaw ceny dla wszystkich typów extra opcji
            if ($type === 'extra_15x23' || $type === 'extra_20x30') {
                $price = $this->extra_print_price;  // 10 zł
                WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['price'] = $price;
            } elseif ($type === 'extra_folio_standard' || $type === 'extra_folio_black' || $type === 'extra_folio') {
                $price = $this->extra_folio_price;  // 30 zł
                WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['price'] = $price;
            } elseif ($type === 'extra_packaging') {
                $price = $this->extra_packaging_price;  // 30 zł
                WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['price'] = $price;
            }

            // Przelicz całkowitą cenę
            $calc_price = $q * $price;

            // KRYTYCZNE: Zaktualizuj pricing_hint (to pole wyświetla APF w kolumnie!)
            $formatted_price = wc_price($calc_price);
            $pricing_hint = '(' . $formatted_price . ')';

            // POPRAWKA v14.3.1: NIE modyfikuj value['label'] dla pól typu number!
            // Dla pól number, value['label'] to TYLKO liczba (np. "2"), a field['label'] to nazwa pola.
            // APF wyświetla jako: field['label'] + ": " + value['label']
            // Jeśli zmienimy value['label'] na "2x Nazwa", APF pokaże: "Nazwa: 2x Nazwa" (duplikacja!)
            //
            // KROK 1: Pobierz aktualny label
            $current_label = WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['label'] ?? '';

            // KROK 2: Wyczyść label ze starych prefiksów ilości (np. "2x" ze starej wersji wtyczki)
            $clean_label = $this->strip_qty_from_label($current_label);
            $this->log("  Oczyszczony label: '$current_label' → '$clean_label'");

            // KROK 3: Sprawdź czy to pole typu number (czysty label jest tylko liczbą lub pusty)
            if (preg_match('/^\d+$/', $clean_label) || empty($clean_label)) {
                // To pole number - zapisz tylko nową ilość (bez prefiksu "2x")
                $updated_label = (string)$q;
                $this->log("  Label jest liczbą lub pusty → ustawiam na $q (bez prefiksu)");
            } else {
                // To inne pole (np. swatch) - formatuj z ilością jeśli potrzeba
                $updated_label = $this->format_label_with_qty($clean_label, $q);
                $this->log("  Label jest tekstem ('$clean_label') → formatuję: $updated_label");
            }

            // Zapisz nową ilość i cenę
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['_apf_qty'] = $q;
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['qty'] = $q;
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['calc_price'] = $calc_price;
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['pricing_hint'] = $pricing_hint;
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['label'] = $updated_label;

            // POPRAWKA v3: Dodaj także 'quantity' dla kompatybilności z APF
            if (!isset(WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['quantity'])) {
                WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['quantity'] = [];
            }
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['quantity']['qty'] = $q;

            $this->log("  Zaktualizowano: qty=$q, price=$price, calc_price=$calc_price, pricing_hint=$pricing_hint, label=$updated_label");

            // LOGIKA: Jeśli usuwamy główną pozycję (qty=0), wyzeruj też dodatkowe
            if ($q === 0) {
                if ($type === 'print_15x23' || $type === 'print_20x30') {
                    $extra_type = ($type === 'print_15x23') ? 'extra_15x23' : 'extra_20x30';
                    $this->zero_related_extras($k, $extra_type);
                } elseif ($type === 'packaging') {
                    $this->zero_related_extras($k, 'extra_packaging');
                }
            }

            // WYMUSZENIE 1: Zapisz do cart_contents
            WC()->cart->set_cart_contents(WC()->cart->cart_contents);

            // WYMUSZENIE 2: Przelicz totals (to może nadpisać nasze wartości!)
            // Dlatego zapisujemy PONOWNIE po calculate_totals
            WC()->cart->calculate_totals();

            // WYMUSZENIE 3: PONOWNIE zapisz wartości (na wypadek gdyby calculate_totals je nadpisał)
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['_apf_qty'] = $q;
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['qty'] = $q;
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['calc_price'] = $calc_price;
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['pricing_hint'] = $pricing_hint;
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['label'] = $updated_label;
            if (!isset(WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['quantity'])) {
                WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['quantity'] = [];
            }
            WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['quantity']['qty'] = $q;

            // WYMUSZENIE 4: Ponownie zapisz cart_contents
            WC()->cart->set_cart_contents(WC()->cart->cart_contents);

            // WYMUSZENIE 5: Zapisz session
            WC()->session->set('cart', WC()->cart->get_cart_for_session());

            // WYMUSZENIE 6: Zapisz sesję do bazy
            if (method_exists(WC()->session, 'save_data')) {
                WC()->session->save_data();
            }

            // WYMUSZENIE 7: Persistent cart (dla zalogowanych użytkowników)
            if (method_exists(WC()->cart, 'persistent_cart_save')) {
                WC()->cart->persistent_cart_save();
            }

            // DEBUG: Sprawdź co faktycznie zostało zapisane
            $saved_qty = WC()->cart->cart_contents[$k]['wapf'][$f]['values'][$v]['_apf_qty'] ?? 'BRAK';
            $this->log("  PO ZAPISIE: _apf_qty=$saved_qty, wysyłam do JS: q=$q");

            wp_send_json_success(['q' => $q]);
        }

        /**
         * POPRAWIONA v2: Zeruje powiązane dodatkowe pozycje (ale nie usuwa z koszyka)
         */
        private function zero_related_extras($cart_key, $extra_type) {
            if (!isset(WC()->cart->cart_contents[$cart_key]['wapf'])) return;

            $this->log("  Zeruję powiązane dodatkowe typu: $extra_type");

            foreach (WC()->cart->cart_contents[$cart_key]['wapf'] as $fi => $field) {
                if (!isset($field['values'])) continue;

                foreach ($field['values'] as $vi => $value) {
                    $label = $field['label'] ?? ($value['label'] ?? '');
                    $current_type = $this->get_field_type($label, $value);

                    if ($current_type === $extra_type) {
                        WC()->cart->cart_contents[$cart_key]['wapf'][$fi]['values'][$vi]['_apf_qty'] = 0;
                        WC()->cart->cart_contents[$cart_key]['wapf'][$fi]['values'][$vi]['qty'] = 0;
                        WC()->cart->cart_contents[$cart_key]['wapf'][$fi]['values'][$vi]['calc_price'] = 0;
                        $this->log("    Wyzerowano: $label");
                    }
                }
            }
        }

        /**
         * POPRAWIONA v2: Usuwa pojedynczą opcję + kaskadowo usuwa powiązane dodatkowe
         */
        public function ajax_remove_option() {
            check_ajax_referer('apf14', 'n');

            $key = sanitize_text_field($_POST['k'] ?? '');
            $field_id = intval($_POST['f'] ?? 0);
            $value_id = intval($_POST['v'] ?? 0);
            $type = sanitize_text_field($_POST['type'] ?? '');

            $this->log("AJAX REMOVE OPTION: key=$key, field=$field_id, value=$value_id, type=$type");

            if (!WC()->cart || !isset(WC()->cart->cart_contents[$key])) {
                wp_send_json_error(['m' => 'Produkt nie istnieje']);
            }

            if (!isset(WC()->cart->cart_contents[$key]['wapf'][$field_id]['values'][$value_id])) {
                wp_send_json_error(['m' => 'Opcja nie istnieje']);
            }

            // LOGIKA KASKADOWA: Jeśli usuwamy główną pozycję, usuń też powiązane dodatkowe
            if ($type === 'print_15x23' || $type === 'print_20x30') {
                $extra_type = ($type === 'print_15x23') ? 'extra_15x23' : 'extra_20x30';
                $this->remove_related_extras($key, $extra_type);
            } elseif ($type === 'packaging') {
                $this->remove_related_extras($key, 'extra_packaging');
            } elseif ($type === 'folio') {
                $this->remove_related_extras($key, 'extra_folio');
            } elseif ($type === 'folio_standard') {
                $this->remove_related_extras($key, 'extra_folio_standard');
            } elseif ($type === 'folio_black') {
                $this->remove_related_extras($key, 'extra_folio_black');
            }

            // Usuń główną opcję
            unset(WC()->cart->cart_contents[$key]['wapf'][$field_id]['values'][$value_id]);

            // Jeśli nie ma więcej wartości w tym polu, usuń pole
            if (empty(WC()->cart->cart_contents[$key]['wapf'][$field_id]['values'])) {
                unset(WC()->cart->cart_contents[$key]['wapf'][$field_id]);
            }

            WC()->cart->set_cart_contents(WC()->cart->cart_contents);
            WC()->cart->calculate_totals();

            wp_send_json_success(['m' => 'Opcja usunięta']);
        }

        /**
         * POPRAWIONA v2: Usuwa powiązane dodatkowe pozycje kaskadowo (całkowite usunięcie z koszyka)
         */
        private function remove_related_extras($cart_key, $extra_type) {
            if (!isset(WC()->cart->cart_contents[$cart_key]['wapf'])) return;

            $this->log("  Usuwam kaskadowo powiązane dodatkowe typu: $extra_type");

            foreach (WC()->cart->cart_contents[$cart_key]['wapf'] as $fi => $field) {
                if (!isset($field['values'])) continue;

                foreach ($field['values'] as $vi => $value) {
                    // Pobierz label z field['label'] (pełna nazwa pola)
                    $field_label = $field['label'] ?? '';
                    $value_label = $value['label'] ?? '';

                    // Użyj field label jeśli dostępny, inaczej value label
                    $label = !empty($field_label) ? $field_label : $value_label;

                    $current_type = $this->get_field_type($label, $value);

                    $this->log("    Sprawdzam: field_label='$field_label', value_label='$value_label', label='$label', type=$current_type");

                    if ($current_type === $extra_type) {
                        $this->log("    ✓ USUWAM: $label (fi=$fi, vi=$vi)");
                        unset(WC()->cart->cart_contents[$cart_key]['wapf'][$fi]['values'][$vi]);
                    } else {
                        $this->log("    → Pomijam: $label (oczekiwano: $extra_type, jest: $current_type)");
                    }
                }

                // Jeśli pole nie ma już wartości, usuń je całkowicie
                if (isset(WC()->cart->cart_contents[$cart_key]['wapf'][$fi]) &&
                    empty(WC()->cart->cart_contents[$cart_key]['wapf'][$fi]['values'])) {
                    $this->log("    Usuwam puste pole: fi=$fi");
                    unset(WC()->cart->cart_contents[$cart_key]['wapf'][$fi]);
                }
            }
        }

        /**
         * NOWA: Usuwa CAŁY PRODUKT z koszyka
         */
        public function ajax_remove_product() {
            check_ajax_referer('apf14', 'n');

            $key = sanitize_text_field($_POST['k'] ?? '');

            $this->log("AJAX REMOVE PRODUCT: key=$key");

            if (!WC()->cart) {
                wp_send_json_error(['m' => 'Brak koszyka']);
            }

            // Usuń produkt z koszyka
            $removed = WC()->cart->remove_cart_item($key);

            if ($removed) {
                $this->log("  Produkt usunięty z koszyka");
                wp_send_json_success(['m' => 'Produkt usunięty']);
            } else {
                wp_send_json_error(['m' => 'Nie można usunąć produktu']);
            }
        }

        /**
         * Przelicza ceny
         */
        public function calc($cart) {
            if (!is_object($cart) || empty($cart->cart_contents)) return;

            $this->log('=== CALC START ===');

            foreach ($cart->get_cart() as $key => $item) {
                if (!isset($item['wapf']) || !is_array($item['wapf'])) {
                    continue;
                }

                $total = 0;
                $details = [];

                foreach ($item['wapf'] as $fi => $field) {
                    if (!isset($field['values']) || !is_array($field['values'])) continue;

                    foreach ($field['values'] as $vi => $value) {
                        // DEBUG: Pokaż wszystkie dostępne klucze w $value
                        $debug_keys = array_keys($value);
                        $this->log("    DEBUG value keys: " . implode(', ', $debug_keys));

                        // POPRAWKA v3: Użyj aktualnej wartości qty (jeśli została ustawiona przez ajax_set)
                        // Najpierw sprawdź _apf_qty, potem qty, na końcu wywołaj get_qty()
                        $source = '';
                        if (isset($value['_apf_qty']) && $value['_apf_qty'] >= 0) {
                            $qty = intval($value['_apf_qty']);
                            $source = '_apf_qty';
                        } elseif (isset($value['qty']) && $value['qty'] >= 0) {
                            $qty = intval($value['qty']);
                            $source = 'qty';
                        } else {
                            $qty = $this->get_qty($value, $value['label'] ?? '');
                            $source = 'get_qty()';
                            // Zapisz qty jeśli nie było
                            $cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['_apf_qty'] = $qty;
                            $cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['qty'] = $qty;
                        }

                        $this->log("    qty=$qty (source=$source), _apf_qty=" . ($value['_apf_qty'] ?? 'BRAK') . ", qty=" . ($value['qty'] ?? 'BRAK') . ", quantity[qty]=" . ($value['quantity']['qty'] ?? 'BRAK'));

                        // POPRAWKA: Używaj field['label'] jeśli dostępne (pełna nazwa pola)
                        $field_label = $field['label'] ?? '';
                        $value_label = $value['label'] ?? '';
                        $label = !empty($field_label) ? $field_label : $value_label;

                        // POPRAWKA v2: Przekaż $value jako drugi parametr do get_field_type()
                        $type = $this->get_field_type($label, $value);

                        // POPRAWKA v14.3.0: Ceny dla wszystkich extra opcji
                        if ($type === 'extra_15x23' || $type === 'extra_20x30') {
                            $price = $this->extra_print_price;  // 10 zł
                            $line = $qty * $price;
                            $cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['price'] = $price;
                        } elseif ($type === 'extra_folio_standard' || $type === 'extra_folio_black' || $type === 'extra_folio') {
                            $price = $this->extra_folio_price;  // 30 zł
                            $line = $qty * $price;
                            $cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['price'] = $price;
                        } elseif ($type === 'extra_packaging') {
                            $price = $this->extra_packaging_price;  // 30 zł
                            $line = $qty * $price;
                            $cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['price'] = $price;
                        } else {
                            $price = floatval($value['price'] ?? 0);
                            $line = $qty * $price;
                        }

                        $details[] = "$label: qty=$qty × price=$price = $line";
                        $cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['calc_price'] = $line;

                        // KRYTYCZNE v14.2.4: Aktualizuj pricing_hint (wyświetlane w kolumnie APF)
                        $formatted_price = wc_price($line);
                        $pricing_hint = '(' . $formatted_price . ')';
                        $cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['pricing_hint'] = $pricing_hint;

                        $total += $line;
                    }
                }

                $this->log("  Item $key: " . implode(' | ', $details));
                $this->log("  TOTAL: $total");

                if (isset($cart->cart_contents[$key]['data'])) {
                    $cart->cart_contents[$key]['data']->set_price($total);
                }
            }

            $this->log('=== CALC END ===');
        }

        /**
         * KRYTYCZNE: Przywraca qty wartości AFTER calculate_totals
         * Wykonuje się z priority 99999, po wszystkich innych hookach
         */
        public function restore_qty($cart) {
            if (!is_object($cart) || empty($cart->cart_contents)) return;

            $this->log('=== RESTORE QTY START ===');

            foreach ($cart->cart_contents as $key => $item) {
                if (!isset($item['wapf']) || !is_array($item['wapf'])) continue;

                foreach ($item['wapf'] as $fi => $field) {
                    if (!isset($field['values']) || !is_array($field['values'])) continue;

                    foreach ($field['values'] as $vi => $value) {
                        // Jeśli mamy zapisaną wartość _apf_qty, upewnij się że qty i quantity[qty] są zsynchronizowane
                        if (isset($value['_apf_qty'])) {
                            $qty = intval($value['_apf_qty']);

                            // Nadpisz qty i quantity[qty] wartością z _apf_qty
                            $cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['qty'] = $qty;

                            if (!isset($cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['quantity'])) {
                                $cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['quantity'] = [];
                            }
                            $cart->cart_contents[$key]['wapf'][$fi]['values'][$vi]['quantity']['qty'] = $qty;

                            $this->log("  Restored qty=$qty for field=$fi, value=$vi");
                        }
                    }
                }
            }

            $this->log('=== RESTORE QTY END ===');
        }

        /**
         * Assets
         */
        public function assets() {
            if (!is_cart()) return;

            $nonce = wp_create_nonce('apf14');
            $ajax_url = admin_url('admin-ajax.php');
            ?>
<style id="apf-cart-pro-v14-1-styles">
.wc-block-cart .wc-block-cart-item__quantity { display: none !important; }

.apf-row {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    padding: 12px 16px !important;
    margin: 6px 0 !important;
    background: #f8f9fa !important;
    border-radius: 8px !important;
    border-left: 4px solid #2271b1 !important;
    transition: all 0.2s ease !important;
}

.apf-row:hover {
    background: #e8f4f8 !important;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05) !important;
}

.apf-label {
    flex: 1 !important;
    font-size: 14px !important;
    font-weight: 500 !important;
    color: #333 !important;
    padding-right: 12px !important;
}

.apf-ctrls {
    display: flex !important;
    gap: 10px !important;
    align-items: center !important;
}

.apf-box {
    display: flex !important;
    border: 2px solid #2271b1 !important;
    border-radius: 6px !important;
    overflow: hidden !important;
    background: white !important;
}

.apf-btn {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    width: 36px !important;
    height: 36px !important;
    border: none !important;
    background: #2271b1 !important;
    color: white !important;
    cursor: pointer !important;
    font-size: 18px !important;
    font-weight: bold !important;
    transition: background 0.2s ease !important;
    user-select: none !important;
}

.apf-btn:hover:not(:disabled) {
    background: #135e96 !important;
}

.apf-btn:disabled {
    background: #ccc !important;
    cursor: not-allowed !important;
    opacity: 0.6 !important;
}

.apf-num {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    min-width: 40px !important;
    padding: 0 8px !important;
    font-size: 16px !important;
    font-weight: 600 !important;
    color: #2271b1 !important;
    background: white !important;
}

.apf-del {
    display: inline-flex !important;
    align-items: center !important;
    padding: 8px 14px !important;
    background: #dc3545 !important;
    color: white !important;
    border-radius: 6px !important;
    text-decoration: none !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    transition: background 0.2s ease !important;
    border: none !important;
    cursor: pointer !important;
}

.apf-del:hover {
    background: #c82333 !important;
    color: white !important;
}

/* NOWY: Przycisk do usunięcia całego produktu */
.apf-remove-product {
    display: inline-block !important;
    padding: 10px 20px !important;
    background: #6c757d !important;
    color: white !important;
    border-radius: 8px !important;
    text-decoration: none !important;
    font-size: 14px !important;
    font-weight: 600 !important;
    margin-top: 10px !important;
    border: 2px solid #5a6268 !important;
    cursor: pointer !important;
    transition: all 0.3s ease !important;
}

.apf-remove-product:hover {
    background: #5a6268 !important;
    color: white !important;
    transform: scale(1.05) !important;
}

.apf-badge {
    display: inline-block !important;
    padding: 2px 8px !important;
    margin-left: 8px !important;
    font-size: 11px !important;
    font-weight: 600 !important;
    border-radius: 4px !important;
    background: #17a2b8 !important;
    color: white !important;
}

.apf-badge-extra {
    background: #28a745 !important;
}

.apf-badge-price {
    background: #ffc107 !important;
    color: #000 !important;
}

.apf-price-info {
    font-size: 12px !important;
    color: #dc3545 !important;
    font-weight: 600 !important;
}

@media (max-width: 768px) {
    .apf-row {
        flex-direction: column !important;
        align-items: flex-start !important;
    }
    .apf-ctrls {
        width: 100% !important;
        margin-top: 8px !important;
    }
}
</style>

<script id="apf-cart-pro-v14-1-script">
(function() {
    'use strict';

    console.log('[APF v14.1 DEBUG] Inicjalizacja...');

    const CFG = {
        ajax: <?php echo json_encode($ajax_url); ?>,
        nonce: <?php echo json_encode($nonce); ?>,
        extraPrintPrice: <?php echo json_encode($this->extra_print_price); ?>
    };

    let data = [];
    let busy = false;

    function getFieldType(label) {
        const l = label.toLowerCase();

        if (l.includes('wersja elektroniczna') || l.includes('jpg')) {
            return 'electronic';
        }

        // DODATKOWE opakowania (sprawdzaj PRZED głównymi)
        if ((l.includes('dodatkow') || l.includes('ilość dodatkowych')) &&
            (l.includes('opakowa') || l.includes('box'))) {
            return 'extra_packaging';
        }

        // DODATKOWE karty Folio (sprawdzaj PRZED głównymi)
        if ((l.includes('dodatkow') || l.includes('ilość dodatkowych')) && l.includes('folio')) {
            if (l.includes('standard')) return 'extra_folio_standard';
            if (l.includes('czarna')) return 'extra_folio_black';
            return 'extra_folio';
        }

        // GŁÓWNE opakowania BOX
        if (l.includes('opakowanie box') || (l.includes('dodatki') && l.includes('opakowanie'))) {
            return 'packaging';
        }

        // GŁÓWNE karty Folio BOX
        if (l.includes('folio')) {
            if (l.includes('standard')) return 'folio_standard';
            if (l.includes('czarna')) return 'folio_black';
            return 'folio';
        }

        if (l.includes('wydruk odbitki')) {
            if (/15\s*x\s*23|15x23/i.test(label)) return 'print_15x23';
            if (/20\s*x\s*30|20x30/i.test(label)) return 'print_20x30';
            return 'print';
        }

        if ((l.includes('dodatkow') && l.includes('odbitek')) || l.includes('ilość dodatkowych odbitek')) {
            if (/15\s*x\s*23|15x23/i.test(label)) return 'extra_15x23';
            if (/20\s*x\s*30|20x30/i.test(label)) return 'extra_20x30';
        }

        return 'standard';
    }

    function isMainPrintActive(cartData, type) {
        for (const item of cartData) {
            for (const opt of item.wapf) {
                if (opt.type === type && opt.qty > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    function render() {
        console.log('[APF v14.1.7 DEBUG] Renderowanie...');

        const metas = document.querySelectorAll('ul.wc-block-components-product-details');
        if (!metas.length) {
            console.log('[APF v14.1.7 DEBUG] Brak metadata');
            return;
        }

        // NOWE v14.2.8: Policz produkty z/bez APF
        let withApf = 0;
        let withoutApf = 0;

        data.forEach((item, idx) => {
            if (item.wapf && item.wapf.length > 0) {
                withApf++;
            } else {
                withoutApf++;
                console.log(`[APF v14.1.7 DEBUG] ⚠️ Produkt ${idx} "${item.name || 'bez nazwy'}" nie ma pól APF (wapf) - pomijam`);
            }
        });

        console.log(`[APF v14.1.7 DEBUG] Produkty: ${withApf} z APF, ${withoutApf} bez APF`);

        if (withApf === 0 && withoutApf > 0) {
            console.warn('[APF Cart Editor] ⚠️ UWAGA: Żaden produkt nie ma pól Advanced Product Fields (APF). Panel edycji nie zostanie wyświetlony.');
            console.warn('[APF Cart Editor] Produkty muszą mieć pola APF aby można było je edytować przez tę wtyczkę.');
        }

        let rendered = 0;

        data.forEach((item, idx) => {
            if (!item.wapf || idx >= metas.length) return;

            const meta = metas[idx];

            // Usuń stare kontrolki
            meta.querySelectorAll('.apf-row, .apf-remove-product').forEach(el => el.remove());

            const print15Active = isMainPrintActive([item], 'print_15x23');
            const print20Active = isMainPrintActive([item], 'print_20x30');
            const packagingActive = isMainPrintActive([item], 'packaging');
            const folioActive = isMainPrintActive([item], 'folio');
            const folioStandardActive = isMainPrintActive([item], 'folio_standard');
            const folioBlackActive = isMainPrintActive([item], 'folio_black');

            console.log(`[APF v14.1.7 DEBUG] Produkt ${idx}: 15x23=${print15Active}, 20x30=${print20Active}, packaging=${packagingActive}, folio=${folioActive}, folio_std=${folioStandardActive}, folio_blk=${folioBlackActive}`);

            item.wapf.forEach(opt => {
                console.log(`  Opcja: ${opt.label}, type=${opt.type}, qty=${opt.qty}`);

                // POPRAWIONA LOGIKA v14.2.9: Ukryj opcje z qty=0,
                // CHYBA ŻE to extra opcja I główna opcja jest aktywna
                if (opt.qty === 0) {
                    let showExtra = false;

                    // Sprawdź czy to extra i czy odpowiednia główna opcja jest aktywna
                    if (opt.type === 'extra_15x23' && print15Active) showExtra = true;
                    if (opt.type === 'extra_20x30' && print20Active) showExtra = true;
                    if (opt.type === 'extra_packaging' && packagingActive) showExtra = true;
                    if (opt.type === 'extra_folio_standard' && folioStandardActive) showExtra = true;
                    if (opt.type === 'extra_folio_black' && folioBlackActive) showExtra = true;
                    if (opt.type === 'extra_folio' && folioActive) showExtra = true;

                    if (!showExtra) {
                        console.log(`    → Ukrywam (qty=0, brak głównej opcji lub nie jest extra)`);
                        return; // Ukryj tę opcję
                    }
                    console.log(`    → Pokazuję extra mimo qty=0 (główna opcja aktywna)`);
                }

                const li = document.createElement('li');
                li.className = 'wc-block-components-product-details__item apf-row';

                // POPRAWKA v14.2.4: Nie formatuj nazw - APF już przesyła pełne nazwy z PHP
                // Usunięto duplikację typów (Standard, Czarna ramka, 15x23cm itp.)
                const displayLabel = opt.label;

                const label = document.createElement('span');
                label.className = 'apf-label';
                label.textContent = displayLabel;

                // Badge dla dodatkowych odbitek
                if (opt.type === 'extra_15x23' || opt.type === 'extra_20x30') {
                    const badge = document.createElement('span');
                    badge.className = 'apf-badge apf-badge-extra';
                    badge.textContent = '+ Dodatkowe';
                    label.appendChild(badge);

                    const priceBadge = document.createElement('span');
                    priceBadge.className = 'apf-badge apf-badge-price';
                    priceBadge.textContent = CFG.extraPrintPrice.toFixed(2) + ' zł/szt';
                    label.appendChild(priceBadge);
                }

                li.appendChild(label);

                const ctrls = document.createElement('div');
                ctrls.className = 'apf-ctrls';

                // Elektroniczna - tylko usuń
                if (opt.type === 'electronic') {
                    const del = document.createElement('button');
                    del.className = 'apf-del';
                    del.textContent = 'Usuń';
                    del.onclick = () => {
                        if (confirm('Usunąć wersję elektroniczną?')) {
                            removeOption(item.key, opt.fi, opt.vi, opt.type);
                        }
                    };
                    ctrls.appendChild(del);
                }
                // Główna odbitka - max 1
                else if (opt.type === 'print_15x23' || opt.type === 'print_20x30' || opt.type === 'print') {
                    const box = document.createElement('div');
                    box.className = 'apf-box';

                    const minus = document.createElement('button');
                    minus.className = 'apf-btn';
                    minus.textContent = '−';
                    minus.disabled = opt.qty <= 0;
                    minus.onclick = () => setQty(item.key, opt.fi, opt.vi, 0, opt.type);

                    const num = document.createElement('span');
                    num.className = 'apf-num';
                    num.textContent = opt.qty;

                    const plus = document.createElement('button');
                    plus.className = 'apf-btn';
                    plus.textContent = '+';
                    plus.disabled = opt.qty >= 1; // POPRAWKA: zablokowany gdy już jest 1
                    plus.onclick = () => {
                        if (opt.qty >= 1) {
                            alert('Główna odbitka może być tylko 1 sztuka.\n\nAby dodać więcej, użyj pola "Ilość dodatkowych odbitek"');
                        } else {
                            setQty(item.key, opt.fi, opt.vi, 1, opt.type);
                        }
                    };

                    box.appendChild(minus);
                    box.appendChild(num);
                    box.appendChild(plus);
                    ctrls.appendChild(box);

                    const del = document.createElement('button');
                    del.className = 'apf-del';
                    del.textContent = 'Usuń';
                    del.onclick = () => {
                        if (confirm('Usunąć tę odbitkę?\n\nUWAGA: Dodatkowe odbitki tego formatu zostaną wyzerowane!')) {
                            removeOption(item.key, opt.fi, opt.vi, opt.type);
                        }
                    };
                    ctrls.appendChild(del);
                }
                // GŁÓWNE karty Folio BOX (max qty=1, jak główne odbitki)
                else if (opt.type === 'folio' || opt.type === 'folio_standard' || opt.type === 'folio_black') {
                    console.log(`  → Renderuję główną kartę Folio: type=${opt.type}, qty=${opt.qty}`);

                    const box = document.createElement('div');
                    box.className = 'apf-box';

                    const minus = document.createElement('button');
                    minus.className = 'apf-btn';
                    minus.textContent = '−';
                    minus.disabled = opt.qty <= 0;
                    minus.onclick = () => setQty(item.key, opt.fi, opt.vi, 0, opt.type);

                    const num = document.createElement('span');
                    num.className = 'apf-num';
                    num.textContent = opt.qty;

                    const plus = document.createElement('button');
                    plus.className = 'apf-btn';
                    plus.textContent = '+';
                    plus.disabled = opt.qty >= 1; // POPRAWKA: zablokowany gdy już jest 1

                    console.log(`  → Przycisk (+) dla ${opt.type}: qty=${opt.qty}, disabled=${opt.qty >= 1}`);

                    plus.onclick = () => {
                        if (opt.qty >= 1) {
                            alert('Główna karta Folio może być tylko 1 sztuka.\n\nAby dodać więcej, użyj pola "Ilość dodatkowych kart Folio BOX"');
                        } else {
                            setQty(item.key, opt.fi, opt.vi, 1, opt.type);
                        }
                    };

                    box.appendChild(minus);
                    box.appendChild(num);
                    box.appendChild(plus);
                    ctrls.appendChild(box);

                    const del = document.createElement('button');
                    del.className = 'apf-del';
                    del.textContent = 'Usuń';
                    del.onclick = () => {
                        if (confirm('Usunąć tę kartę Folio?\n\nUWAGA: Dodatkowe karty tego typu zostaną usunięte!')) {
                            removeOption(item.key, opt.fi, opt.vi, opt.type);
                        }
                    };
                    ctrls.appendChild(del);
                }
                // GŁÓWNE opakowania BOX (max qty=1, jak główne odbitki)
                else if (opt.type === 'packaging') {
                    const box = document.createElement('div');
                    box.className = 'apf-box';

                    const minus = document.createElement('button');
                    minus.className = 'apf-btn';
                    minus.textContent = '−';
                    minus.disabled = opt.qty <= 0;
                    minus.onclick = () => setQty(item.key, opt.fi, opt.vi, 0, opt.type);

                    const num = document.createElement('span');
                    num.className = 'apf-num';
                    num.textContent = opt.qty;

                    const plus = document.createElement('button');
                    plus.className = 'apf-btn';
                    plus.textContent = '+';
                    plus.disabled = opt.qty >= 1; // POPRAWKA: zablokowany gdy już jest 1
                    plus.onclick = () => {
                        if (opt.qty >= 1) {
                            alert('Główne opakowanie może być tylko 1 sztuka.\n\nAby dodać więcej, użyj pola "Ilość dodatkowych opakowań"');
                        } else {
                            setQty(item.key, opt.fi, opt.vi, 1, opt.type);
                        }
                    };

                    box.appendChild(minus);
                    box.appendChild(num);
                    box.appendChild(plus);
                    ctrls.appendChild(box);

                    const del = document.createElement('button');
                    del.className = 'apf-del';
                    del.textContent = 'Usuń';
                    del.onclick = () => {
                        if (confirm('Usunąć to opakowanie?\n\nUWAGA: Dodatkowe opakowania zostaną usunięte!')) {
                            removeOption(item.key, opt.fi, opt.vi, opt.type);
                        }
                    };
                    ctrls.appendChild(del);
                }
                // DODATKOWE karty Folio BOX
                else if (opt.type === 'extra_folio' || opt.type === 'extra_folio_standard' || opt.type === 'extra_folio_black') {
                    // Sprawdź czy jest główna karta odpowiedniego typu
                    let mainActive = false;
                    let cardType = '';

                    if (opt.type === 'extra_folio_standard') {
                        mainActive = folioStandardActive;
                        cardType = 'Standard';
                    } else if (opt.type === 'extra_folio_black') {
                        mainActive = folioBlackActive;
                        cardType = 'Czarna ramka';
                    } else {
                        mainActive = folioActive;
                        cardType = 'Folio';
                    }

                    const box = document.createElement('div');
                    box.className = 'apf-box';

                    const minus = document.createElement('button');
                    minus.className = 'apf-btn';
                    minus.textContent = '−';
                    minus.disabled = opt.qty <= 0;
                    minus.onclick = () => setQty(item.key, opt.fi, opt.vi, Math.max(0, opt.qty - 1), opt.type);

                    const num = document.createElement('span');
                    num.className = 'apf-num';
                    num.textContent = opt.qty;

                    const plus = document.createElement('button');
                    plus.className = 'apf-btn';
                    plus.textContent = '+';
                    plus.disabled = !mainActive; // POPRAWKA: aktywny TYLKO gdy jest główna karta
                    plus.onclick = () => {
                        if (!mainActive) {
                            alert(`Najpierw dodaj główną kartę Folio BOX ${cardType}`);
                        } else {
                            setQty(item.key, opt.fi, opt.vi, opt.qty + 1, opt.type);
                        }
                    };

                    box.appendChild(minus);
                    box.appendChild(num);
                    box.appendChild(plus);
                    ctrls.appendChild(box);

                    if (!mainActive) {
                        const info = document.createElement('span');
                        info.className = 'apf-price-info';
                        info.textContent = '(dodaj główną kartę)';
                        ctrls.appendChild(info);
                    }
                }
                // DODATKOWE opakowania
                else if (opt.type === 'extra_packaging') {
                    const box = document.createElement('div');
                    box.className = 'apf-box';

                    const minus = document.createElement('button');
                    minus.className = 'apf-btn';
                    minus.textContent = '−';
                    minus.disabled = opt.qty <= 0;
                    minus.onclick = () => setQty(item.key, opt.fi, opt.vi, Math.max(0, opt.qty - 1), opt.type);

                    const num = document.createElement('span');
                    num.className = 'apf-num';
                    num.textContent = opt.qty;

                    const plus = document.createElement('button');
                    plus.className = 'apf-btn';
                    plus.textContent = '+';
                    plus.disabled = !packagingActive; // POPRAWKA: aktywny TYLKO gdy jest główne opakowanie
                    plus.onclick = () => {
                        if (!packagingActive) {
                            alert('Najpierw dodaj główne opakowanie BOX');
                        } else {
                            setQty(item.key, opt.fi, opt.vi, opt.qty + 1, opt.type);
                        }
                    };

                    box.appendChild(minus);
                    box.appendChild(num);
                    box.appendChild(plus);
                    ctrls.appendChild(box);

                    if (!packagingActive) {
                        const info = document.createElement('span');
                        info.className = 'apf-price-info';
                        info.textContent = '(dodaj główne opakowanie)';
                        ctrls.appendChild(info);
                    }
                }
                // DODATKOWE odbitki
                else if (opt.type === 'extra_15x23' || opt.type === 'extra_20x30') {
                    const mainType = opt.type === 'extra_15x23' ? 'print_15x23' : 'print_20x30';
                    const mainActive = opt.type === 'extra_15x23' ? print15Active : print20Active;

                    const box = document.createElement('div');
                    box.className = 'apf-box';

                    const minus = document.createElement('button');
                    minus.className = 'apf-btn';
                    minus.textContent = '−';
                    minus.disabled = opt.qty <= 0;
                    minus.onclick = () => setQty(item.key, opt.fi, opt.vi, Math.max(0, opt.qty - 1), opt.type);

                    const num = document.createElement('span');
                    num.className = 'apf-num';
                    num.textContent = opt.qty;

                    const plus = document.createElement('button');
                    plus.className = 'apf-btn';
                    plus.textContent = '+';
                    plus.disabled = !mainActive; // POPRAWKA: aktywny TYLKO gdy jest główna odbitka
                    plus.onclick = () => {
                        if (!mainActive) {
                            const size = opt.type === 'extra_15x23' ? '15x23cm' : '20x30cm';
                            alert(`Najpierw dodaj główną odbitkę ${size}`);
                        } else {
                            setQty(item.key, opt.fi, opt.vi, opt.qty + 1, opt.type);
                        }
                    };

                    box.appendChild(minus);
                    box.appendChild(num);
                    box.appendChild(plus);
                    ctrls.appendChild(box);

                    if (!mainActive) {
                        const info = document.createElement('span');
                        info.className = 'apf-price-info';
                        info.textContent = '(dodaj główną odbitkę)';
                        ctrls.appendChild(info);
                    }
                }
                // Standardowe
                else {
                    const box = document.createElement('div');
                    box.className = 'apf-box';

                    const minus = document.createElement('button');
                    minus.className = 'apf-btn';
                    minus.textContent = '−';
                    minus.disabled = opt.qty <= 0;
                    minus.onclick = () => setQty(item.key, opt.fi, opt.vi, Math.max(0, opt.qty - 1), opt.type);

                    const num = document.createElement('span');
                    num.className = 'apf-num';
                    num.textContent = opt.qty;

                    const plus = document.createElement('button');
                    plus.className = 'apf-btn';
                    plus.textContent = '+';
                    plus.onclick = () => setQty(item.key, opt.fi, opt.vi, opt.qty + 1, opt.type);

                    box.appendChild(minus);
                    box.appendChild(num);
                    box.appendChild(plus);
                    ctrls.appendChild(box);

                    const del = document.createElement('button');
                    del.className = 'apf-del';
                    del.textContent = 'Usuń';
                    del.onclick = () => {
                        if (confirm('Usunąć tę pozycję?')) {
                            removeOption(item.key, opt.fi, opt.vi, opt.type);
                        }
                    };
                    ctrls.appendChild(del);
                }

                li.appendChild(ctrls);
                meta.appendChild(li);
                rendered++;
            });

            // NOWE: Przycisk do usunięcia całego produktu
            const removeProductBtn = document.createElement('a');
            removeProductBtn.href = '#';
            removeProductBtn.className = 'apf-remove-product';
            removeProductBtn.textContent = '🗑️ Usuń całą pozycję';
            removeProductBtn.onclick = (e) => {
                e.preventDefault();
                if (confirm(`Czy na pewno chcesz usunąć cały produkt "${item.product_name}" z koszyka?\n\nUWAGA: Wszystkie opcje zostaną usunięte!`)) {
                    removeProduct(item.key);
                }
            };
            meta.appendChild(removeProductBtn);
        });

        console.log(`[APF v14.1.7 DEBUG] Wyrenderowano ${rendered} opcji`);
    }

    function setQty(k, f, v, q, type) {
        if (busy) return;
        busy = true;

        console.log('[APF v14.1.7 DEBUG] setQty:', {k, f, v, q, type});

        fetch(CFG.ajax, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: new URLSearchParams({
                action: 'apf_set_v14',
                n: CFG.nonce,
                k, f, v, q, type
            })
        })
        .then(r => r.json())
        .then(res => {
            if (res.success) {
                console.log('[APF v14.1.7 DEBUG] Sukces, wymuszam odświeżenie WooCommerce...');

                // KRYTYCZNE: Wymuś odświeżenie fragmentów WooCommerce
                if (typeof jQuery !== 'undefined') {
                    jQuery(document.body).trigger('wc_fragment_refresh');
                    jQuery(document.body).trigger('updated_wc_div');
                    jQuery(document.body).trigger('wc_update_cart');
                }

                // Odśwież całą stronę po krótkiej chwili (jako backup)
                setTimeout(() => location.reload(), 500);
            } else {
                alert('Błąd: ' + (res.data?.m || 'Nieznany błąd'));
                busy = false;
            }
        })
        .catch(err => {
            alert('Błąd: ' + err.message);
            busy = false;
        });
    }

    function removeOption(k, f, v, type) {
        if (busy) return;
        busy = true;

        console.log('[APF v14.1.7 DEBUG] removeOption:', {k, f, v, type});

        fetch(CFG.ajax, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: new URLSearchParams({
                action: 'apf_remove_option_v14',
                n: CFG.nonce,
                k, f, v, type
            })
        })
        .then(r => r.json())
        .then(res => {
            if (res.success) {
                console.log('[APF v14.1.7 DEBUG] Opcja usunięta');
                location.reload();
            } else {
                alert('Błąd: ' + (res.data?.m || 'Nieznany błąd'));
                busy = false;
            }
        })
        .catch(err => {
            alert('Błąd: ' + err.message);
            busy = false;
        });
    }

    function removeProduct(k) {
        if (busy) return;
        busy = true;

        console.log('[APF v14.1.7 DEBUG] removeProduct:', k);

        fetch(CFG.ajax, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: new URLSearchParams({
                action: 'apf_remove_product_v14',
                n: CFG.nonce,
                k
            })
        })
        .then(r => r.json())
        .then(res => {
            if (res.success) {
                console.log('[APF v14.1.7 DEBUG] Produkt usunięty');
                location.reload();
            } else {
                alert('Błąd: ' + (res.data?.m || 'Nieznany błąd'));
                busy = false;
            }
        })
        .catch(err => {
            alert('Błąd: ' + err.message);
            busy = false;
        });
    }

    function fetchData() {
        console.log('[APF v14.1.7 DEBUG] Pobieram dane...');

        fetch(CFG.ajax, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: new URLSearchParams({
                action: 'apf_get_v14',
                n: CFG.nonce
            })
        })
        .then(r => r.json())
        .then(res => {
            if (res.success) {
                data = res.data;
                console.log('[APF v14.1.7 DEBUG] Dane pobrane:', data);
                render();
            } else {
                console.error('[APF v14.1.7 DEBUG] Błąd:', res.data);
            }
        })
        .catch(err => {
            console.error('[APF v14.1.7 DEBUG] Błąd:', err);
        });
    }

    function init() {
        const cart = document.querySelector('[data-block-name="woocommerce/cart"]');
        if (!cart) {
            setTimeout(init, 500);
            return;
        }

        console.log('[APF v14.1.7 DEBUG] Koszyk znaleziony');

        const obs = new MutationObserver(() => {
            const meta = cart.querySelector('ul.wc-block-components-product-details');
            if (meta && !meta.querySelector('.apf-row')) {
                fetchData();
            }
        });

        obs.observe(cart, {childList: true, subtree: true});

        const waitForMeta = () => {
            const meta = cart.querySelector('ul.wc-block-components-product-details');
            if (meta) {
                fetchData();
            } else {
                setTimeout(waitForMeta, 200);
            }
        };

        setTimeout(waitForMeta, 300);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
</script>
            <?php
        }
    }

    APF_Cart::get_instance();
}
